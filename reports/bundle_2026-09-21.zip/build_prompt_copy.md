# BUILD PROMPT v3 (UNATTENDED): Rx Label Search Engine, PDLA Tagger, and Drug-Drug Interaction Checker

Owner: Aidan Colvin (ONYEN aidancol)
Course: INLS 509-001 Information Retrieval, Mini Search Engine Project (semester project)
Prompt version: 2026-09-21, unattended edition
Repo: https://github.com/AidanColvin/AIDANCOLVIN_aidancol_INLS_509_Mini_Search_Engine_Project_Controlled_Vocab
Work branch: `build/rx-label-search`

**THIS IS AN UNATTENDED RUN. Nobody is reading the chat. Never ask a question and wait for an answer. Never stop for approval. Run every phase in order, end to end, until the definition of done in Section 13 is met or a hard blocker in Section 0.3 stops you. Write everything a human would need to know into the report files in Section 11.**

---

## 0. How to use this prompt

### 0.1 Reading order

1. This prompt is the contract for all work on this project. Read every section and every appendix before you write anything.
2. The appendices are verbatim copies of my source documents:
   * **Appendix A:** my goals and requirements, word for word from my messages.
   * **Appendix B:** my Part 1 (Revised), word for word.
   * **Appendix C:** my Part II (17-term PDLA vocabulary), word for word.
   * **Appendix D:** my standing rules for accuracy, writing, code, and docstrings, word for word.
   * **Appendix E:** my example code, word for word, with an audit of what to copy and what not to copy.
3. The appendices are the specification. Do not work from a summary of them. Where the body of this prompt paraphrases an appendix and the two differ, the appendix wins.
4. When rules conflict, follow this order:
   1. Accuracy and safety rules (Section 5).
   2. My coding and docstring rules (Section 8 and Appendix D).
   3. Scope and functional requirements (Sections 1 to 4, 6, 7).
   4. Repo rules (Section 9).
   5. Your own defaults. Your defaults always lose.
5. Never invent a field name, URL, API parameter, function, number, citation, or clinical fact.
6. Do not narrow the scope. Do not add features I did not ask for. If you think something is missing, record it under "Open questions" in the phase report. Do not build it.
7. If something I ask for is a bad idea, record why in the phase report, then build the safest version that still meets the requirement.

### 0.2 Unattended rules

1. **No questions.** When something is ambiguous, pick the option that is safest under Section 5, record the choice and the alternatives in `reports/OPEN_QUESTIONS.md`, and keep going.
2. **No approval gates.** Every gate from earlier versions of this prompt is removed. Phase 0 writes its audit to a file and continues into Phase 1 immediately.
3. **Commit small, commit often.** Commit after every completed module with passing tests, and push the work branch after every commit. If my usage limit cuts the session off, nothing finished should be lost.
4. **Verify before you assert.** Anything marked "verify" in this prompt gets checked against the current official documentation with a web fetch before you code against it. Record what you checked, the URL, and the date in `reports/VERIFIED_FACTS.md`. If a fact cannot be verified, do not use it; record it in `reports/OPEN_QUESTIONS.md` and use the safest fallback.
5. **A failing test is never hidden.** If a test still fails after five distinct fix attempts, mark it `pytest.mark.skip` with a reason string that names the report entry, record the failure with the full traceback in `reports/BLOCKERS.md`, and move on. Never delete a failing test, never weaken an assertion to make it pass, and never mark an expected value as correct without evidence from a label or a cited reference file.
6. **Gold labels are mine.** Phase 4 builds the harness and runs it on a sample file with clearly fake placeholder labels named `gold_sample_PLACEHOLDER.json`. You never write real gold labels.
7. **Deploy is allowed only through the GitHub Actions workflow on `main`.** You do not run a production deploy by hand. If the merge to `main` is blocked, write `reports/MERGE_READY.md` with the exact commands I run, and stop.

### 0.3 Hard blockers (the only reasons to stop early)

Stop, write `reports/BLOCKERS.md` with what happened and the exact next step for me, and end the session if:

* openFDA bulk files cannot be downloaded after three attempts spaced at least two minutes apart.
* `git push` to the work branch fails after three attempts. Before stopping, make sure every commit exists locally and write the recovery commands.
* A safety rule in Section 5 cannot be met for a feature. Skip that feature, record it, and continue if the rest of the phase can still be built; stop only if the whole phase depends on it.

Everything else is not a blocker. Record it and continue.

---

## 1. Mission

Build one open-source system, on one tagged collection of FDA prescription drug labels, that does four jobs:

1. **Search.** Keyword search over all US human prescription drug labels, ranked with BM25, refined with my PDLA controlled-vocabulary terms (T01 to T17) as facet filters joined with AND or OR.
2. **Tag and categorize.** Assign PDLA terms to every label by the exact rules in Appendix C, and categorize each drug by active ingredient (generic name), FDA pharmacologic class, route, and DEA schedule.
3. **Flag interactions.** Take a full medication list of any length, typed the way a clinician writes it, and flag drug-drug interaction risks stated in the FDA labels.
4. **Rate.** Give every flag a tier based on where its warning sits on the label, and show the label evidence behind it.

Deliver it as a free, open-access website on Vercel, backed by a Python backend, in my public GitHub repo, rebuilt weekly so it stays current with openFDA.

**Users** (from Appendix B): pharmacists and their supporting staff; healthcare providers, including doctors, nurses, and clinical staff; patients and family members. The primary design target is a US physician reviewing a patient's medication list. The central question for all users is whether a patient's medications are safe to take together.

**Not limited to one drug class.** The collection covers all human prescription drug classes. Interactions cross classes, such as an antidepressant taken with a muscle relaxant. A design that only searches or checks within one class fails this project.

**Primary source.** FDA drug labels through openFDA. Every clinical statement the tool shows must come from label text or from a cited reference file (Section 4).

**Part 3.** The Part 3 rubric is not released yet. Part 3 will build on Parts 1 and 2 and will be a search engine. Build the backend pieces any search-engine rubric needs. Hold UI polish until I share the Part 3 rubric.

---

## 2. The collection

Apply the scope filters from Appendix B exactly:

1. Keep human prescription labels only: `openfda.product_type` is `HUMAN PRESCRIPTION DRUG`.
2. Keep only labels that have the `openfda` object.
3. Keep only the newest label per active-ingredient set. A combination product counts as its own ingredient set, so combinations stay in the collection.

Implementation rules:

* **Active-ingredient set:** the sorted, de-duplicated, uppercased values of `openfda.substance_name`. Salt forms stay as the label lists them. For example, METFORMIN HYDROCHLORIDE is one entry.
* **Newest:** the latest `effective_time` within the set. Break ties by the highest `version`, then by `id`. Verify these fields exist in the current openFDA label schema before relying on them. If one does not, fall back to `effective_time` alone, then `id`, and record it.
* **Name dictionary:** build it from every label that passes filters 1 and 2, before de-duplication. That way, brand names on labels dropped by filter 3 still resolve to their ingredient set. Example: a user types "Flexeril" and the kept label is a generic cyclobenzaprine label.
* **Counts:** report the count after each filter in a stats file, so every build shows how the collection was narrowed.

---

## 3. The interaction checker: input and output

### 3.1 Input

A free-text medication list of any length. Entries are separated by commas, semicolons, or new lines. The dose may come before or after the name. Names may be brand or generic, in any case, and may be misspelled.

My test input, exactly as I typed it, including spacing and typos:

```
10 mg Zyprexa X 1 daily , 20 mg adderall X 3 daily , 10 mg ambien X daily , trazdone 50 mg X 1 daily , desvenlafaxine 50 mg X 1 daily , Flexril 10 mg X 3 times daily , Lyrica 100 mg X 3 daily
```

### 3.2 Parsing rules

* **Strength:** a number, integer or decimal, followed by a unit: mg, mcg, g, mL, units, or %.
* **Frequency:** recognize "x N daily", "X N times daily", "N times daily", "once / twice / three times / four times daily", "daily" alone (read as 1, with a note), qd, bid, tid, qid, qhs, and "every N hours" (24 / N per day).
* **Output per entry:** raw text, name text, strength value, strength unit, times per day, daily total (strength × times per day, same unit), and parse notes.
  * Example note: frequency read as once daily from "X daily."
* **Never drop an entry silently.** If an entry cannot be parsed or matched, it appears under "Unresolved entries" with the reason.

### 3.3 Name matching

* Match against the name dictionary (Section 2) first. Use stdlib `difflib` for typo tolerance.
* If the best match is below a documented threshold, or two candidates are close, mark the entry "needs confirmation" and show the candidates. Never pick silently.
* Fall back to the RxNorm approximate-match API only if the local dictionary fails. Label the result "matched via RxNorm."
* Always show the mapping chain so the user can see it. Example: "Flexril" → Flexeril → CYCLOBENZAPRINE HYDROCHLORIDE.

### 3.4 Base-ingredient rollup

* Roll salt forms up to the base ingredient for duplication checks. Example: Adderall's four salts → amphetamine and dextroamphetamine.
* Use RxNorm ingredient relationships or label text. Never use a hand-typed mapping without a cited source.
* **Active metabolites** come from a reference file (`data/reference/active_metabolites.json`). Each pair cites the label sentence that states the relationship, with its `set_id`. Example: desvenlafaxine is the major active metabolite of venlafaxine.

### 3.5 Output

**A. Medication table**, one row per entry:

| As entered | Matched name | Generic (active ingredients) | Base ingredients | Brand | FDA class (`pharm_class_epc`, verbatim) | Route | DEA schedule | Daily total | PDLA tags |

* Show `pharm_class_epc` exactly as openFDA gives it. If missing, show "Not listed on label."
* Show all PDLA terms the label carries, T01 to T17. Each tag expands to its evidence: field and sentence.

**B. Alerts ("flag" and "rate")**, three kinds:

1. **Group alert:** two or more listed drugs share T14 (serotonin syndrome), T15 (CNS depression), or T16 (QT prolongation). Raise one alert per shared risk type. List every member drug with its own label sentence, section, `set_id`, `effective_time`, and DailyMed link.
2. **Pair alert:** drug A carries T17, and another listed drug matches a drug or class named in A's `contraindications` text. Show the contraindication sentence.
3. **Duplication flag:** two entries share a base ingredient, or form a cited active-metabolite pair.

**Tier (heuristic, based on label section).** Every alert shows its tier and the word "heuristic":

* **Tier 1, Contraindicated:** the evidence sentence is in `contraindications`.
* **Tier 2, Boxed warning:** the evidence sentence is in `boxed_warning`.
* **Tier 3, Warning:** the evidence sentence is in `warnings_and_cautions`, `warnings`, or `precautions`.
* **Tier 4, Interaction note:** the evidence sentence is only in `drug_interactions`.
* A group alert takes the highest tier found among its member sentences.

**C. Unresolved entries** (Section 3.2), with reasons.

**D. Notice** on every result, word for word:

> Results reflect FDA label text as of {build date}. "No warning found" does not mean a combination is safe. This tool is not validated for clinical use and does not replace clinical judgment or a licensed drug interaction database.

The only negative result wording allowed is: "No warning found in the labels checked."

### 3.6 Acceptance test: my test input

Build this test from fixture labels (Section 9.6). Before you lock any expected value, confirm it against the fixture label's actual sentence. If a label does not say what is expected here, the test follows the label, and you report the difference to me.

* **Parse:** seven entries.
  * olanzapine 10 mg × 1 = 10 mg/day
  * Adderall 20 mg × 3 = 60 mg/day
  * zolpidem 10 mg × 1 = 10 mg/day, with a note that frequency was read from "X daily"
  * trazodone 50 mg × 1 = 50 mg/day
  * desvenlafaxine 50 mg × 1 = 50 mg/day
  * cyclobenzaprine 10 mg × 3 = 30 mg/day
  * pregabalin 100 mg × 3 = 300 mg/day
* **Typos resolve with the mapping shown:** "trazdone" → trazodone; "Flexril" → Flexeril → cyclobenzaprine.
* **Adderall** resolves to its four amphetamine salts, rolled up to amphetamine and dextroamphetamine.
* **Schedules** from `controlled_substance`: amphetamine products CII, zolpidem CIV, pregabalin CV. The other four drugs have no schedule.
* **Expected group alerts**, each to be confirmed against label text:
  * Serotonin syndrome (T14): desvenlafaxine, trazodone, cyclobenzaprine, and amphetamine.
  * CNS depression (T15): olanzapine, zolpidem, trazodone, cyclobenzaprine, and pregabalin.
* **No duplication flags** for this list.
* **Extra duplication tests:**
  * venlafaxine with desvenlafaxine gives a metabolite flag.
  * Adderall with a dextroamphetamine-only product gives an ingredient flag.

---

## 4. Data sources

### 4.1 Allowed

1. **openFDA Drug Label endpoint** (https://open.fda.gov/apis/drug/label/). This is the primary and only source of clinical content.
   * Full builds use the bulk download files listed in the openFDA download manifest (verify the current manifest URL in the openFDA docs).
   * Use the API only for spot checks and fixtures.
   * openFDA updates the API weekly.
2. **NLM RxNorm APIs (RxNav)**, for name normalization and ingredient relationships only. Verify every endpoint name, parameter, and rate limit in NLM's current documentation before use.
3. **FDA "Drug Development and Drug Interactions: Table of Substrates, Inhibitors and Inducers,"** for enzyme-class membership.
   * FDA defines strong and moderate inhibitors as raising a sensitive substrate's AUC ≥5-fold and ≥2- to <5-fold, respectively.
   * FDA says the table gives examples and is not exhaustive. The tool must say so wherever it uses the table.
   * Transcribe it into `data/reference/` with the URL and access date.
4. **ONC high-priority DDI list:** Phansalkar S, et al., J Am Med Inform Assoc 2012;19(5):735-43 (PMC3422823).
   * 15 interactions. The panel says it is not a complete list of all contraindicated pairs.
   * Use it only as a must-fire test floor.
   * Transcribe it from the paper into `data/reference/`. Never write it from memory.
5. **DDInter 2.0** (optional; build only if I approve it later).
   * License CC BY-NC-SA 4.0; last updated 2024-05-14.
   * Keep it as a separate layer in separate files. Never merge it into core data, and never make core output depend on it.

### 4.2 Forbidden

* Lexicomp / UpToDate Lexidrug, Micromedex, First Databank, Medi-Span, Multum, Medscape, Drugs.com, or any scraped website.
* DrugBank data.
* FAERS or TWOSIDES statistical signals as alerts.
* Your own recall of clinical facts.
* **The NLM RxNav Drug Interaction API.** NLM discontinued it on January 2, 2024. Never call it.

### 4.3 openFDA facts already checked (verify again against current docs before coding against them)

* Label text fields are arrays of strings.
* The `openfda` object is optional; some labels lack it.
* The Label endpoint has no `dosage_form` field. Dosage form is described in text, in `dosage_forms_and_strengths`.
* `openfda.pharm_class_cs` means chemical structure, not controlled substance.
* The DEA schedule appears in the label field `controlled_substance`.
* `boxed_warning` is its own field.
* Newer PLR-format labels use `warnings_and_cautions`. Older labels use `warnings` and `precautions`.
* `openfda.brand_name` is copied from the NDC Directory proprietary name. Some products list their generic name there.
* The Label endpoint held 262,883 labels as of its September 18, 2026 update, prescription and over-the-counter combined.

---

## 5. Accuracy and safety rules (non-negotiable)

1. **Evidence on everything.**
   * Every PDLA tag stores the field it came from and the matched sentence or field value.
   * Every alert shows, for each drug: the sentence, section, `set_id`, `effective_time`, and a DailyMed link. Verify the DailyMed setid URL pattern before use.
   * No evidence means no tag and no alert.
2. **Never write "safe," "no interaction," or "compatible."** The only negative wording is "No warning found in the labels checked."
3. **Missing data means omit the term.** Never guess. This is precision over recall, as Appendix C states.
4. **Handle negation.** Sentences such as "no clinically significant interaction was observed" or "no dose adjustment is needed" must not fire a tag or an alert. Keep negation cues in one tested module.
5. **Tiers are a heuristic.** Label them as one in code comments, API output, and on the page.
6. **No clinical facts from memory.** Expected test values come from fixture label text or cited reference files. If a test expectation in this prompt conflicts with a label, the label wins and you tell me.
7. **Never resolve an ambiguous name silently.** Show "needs confirmation" with the candidates.
8. **Design for clinicians, and show the basis.** FDA's CDS software guidance (issued January 2026, re-issued January 29, 2026) excludes from the device definition only software intended for healthcare professionals that lets them independently review the basis for its recommendations. FDA says software for patients or caregivers stays under its digital health policies.
   * Every alert shows its source text.
   * Public-facing wording frames results as "what the FDA label says," not as advice.
   * Before any real clinical launch, I need a regulatory review. That is my step, not yours.
9. **Privacy.** Medication lists are never logged, stored, cached, or sent to any third party. The check function is stateless. No analytics on inputs.
10. **Freshness.** Show the build date on every page and in every API response.

---

## 6. Tagging requirements (PDLA T01 to T17)

1. Implement each term exactly as Appendix C Section 1 defines it, including every "Assign when" and "Do not assign when" clause.
2. Write one rule function per term, named `tag_t01_boxed_warning`, `tag_t02_oral_route`, and so on through `tag_t17_contraindicated_combination`.
   * Each takes one label and gives evidence or `None`.
   * No rule function assigns two terms.
3. Group rule files by property, matching Appendix C:
   * `safety.py`: T01, T04
   * `route.py`: T02
   * `population.py`: T03
   * `patient_info.py`: T05
   * `dosing.py`: T06, T12
   * `dea.py`: T07, T10
   * `product.py`: T08, T09
   * `interaction.py`: T14 to T17
4. **Broader terms are written at indexing time,** in a separate hierarchy module, exactly as Appendix C Section 2 describes:
   * T10 writes T07. T07 also keeps its own rule.
   * T06 or T12 writes T11.
   * Any of T14 to T17 writes T13.
   * T11 and T13 have no rules of their own.
5. **Consistency rules become tests:**
   * No T10 without T07.
   * No T11 without T06 or T12.
   * No T13 without at least one of T14 to T17.
6. **T04:** read percentages from `adverse_reactions` and `adverse_reactions_table` (HTML strings; parse them with stdlib `html.parser`). Count only drug-group columns. If the drug-group column cannot be identified with confidence, do not assign.
7. **T09:** apply the name check and the ANDA check exactly as written.
8. **T17:** also extract the named drugs and drug classes from the contraindication sentence into a structured list, for pair matching.
   * Match classes through `openfda.pharm_class_epc`, `openfda.pharm_class_moa`, and the FDA enzyme table.
   * Read class strings from the data. Never type them from memory.
9. **Traceability:** store a rule version string with every tag, so re-tagging can be traced.
10. **Efficiency** (this answers the note at the top of my example code):
    * Tagging is pure per label, so run it in parallel with `concurrent.futures`.
    * Cache results as JSON, keyed by `set_id` + `effective_time` + rule version, so unchanged labels are not re-tagged each week.
    * Serialize intermediate artifacts (collection, tags, index) as JSON, so each phase reads the previous phase's output instead of recomputing it.

---

## 7. Search requirements

1. **Index:** the main text fields from Appendix B, plus the `openfda` brand, generic, and substance names.
2. **Ranking:** BM25, with `K1 = 1.2` and `B = 0.75` as named module constants.
3. **Tokenizer:** lowercase, strip punctuation, keep numbers. No stemming in version 1; document that choice in the README.
4. **Facets** read stored tags:
   * AND is the intersection of tag sets. OR is the union.
   * Filters apply to the whole collection or to keyword results.
5. **Each result shows:** brand name, generic name, a snippet containing the query terms, PDLA tags, `set_id`, and `effective_time`.
6. **Acceptance tests:** Appendix C Section 3, Scenarios 1 to 3, run against fixture labels.
   * Scenario 1: T06 alone.
   * Scenario 2: keyword "hypertension" + T01 AND T02.
   * Scenario 3: keyword "muscle spasm" + T14 AND T15.
7. **Evaluation harness for Part 3:** read a queries file and a relevance-judgments file, then compute precision@k, recall@k, MAP, and nDCG. Build the harness only. The report waits for the Part 3 rubric.

---

## 8. Coding standards (full text in Appendix D; this section adds nothing looser)

1. Python 3.11+, standard library first. Dependencies allowed now:
   * `pytest`, for tests. Required by my modular-code-standards skill.
   * Nothing else. If a feature seems to need another dependency, use the standard library instead and record the trade-off in `reports/OPEN_QUESTIONS.md`.
2. **One function does one thing.** If the docstring's "does" line needs the word "and," split the function. Build many small functions that compose into jobs, and jobs that compose into the program.
3. **Every function has exactly three docstring lines, in this order:**
   * Line 1 starts with "Takes" and says what the inputs are and what they mean.
   * Line 2 says what the function does: the one action.
   * Line 3 starts with "Gives" and says what comes back, including edge cases. If raising is part of the contract, fold it into this line.
   * One sentence per line. Plain English. No fourth line.
   * No Args, Returns, or Raises blocks. No Google, NumPy, or reStructuredText style.
   * This applies to every function: helpers, entry points, and tests.
   * A function with no arguments says "Takes no arguments."
   * **Note:** my message in Appendix A says "four line" once. The rule is three lines. Appendix D settles it.
4. Full type hints on every parameter and every return, including private helpers.
5. **Separate pure logic from I/O.** A function that reads or writes does not compute. A function that computes does not read or write.
6. No hidden global state. Data comes in through parameters and leaves through returns. Constants live at module level in `UPPER_SNAKE_CASE` and are passed in, not read inside functions.
7. Do not mutate a caller's data. Return new objects.
8. Use guard clauses and return early. Handle the empty case in anything that divides, averages, indexes, or unpacks.
9. Do not shadow builtins: `dir`, `id`, `list`, `type`, `input`, `file`.
10. Catch specific exceptions only. Validate inputs at the boundary (CLI, API handler, file loader). Fail loudly on a missing path, empty corpus, or malformed data.
11. Use frozen `dataclasses` for records: Label, TermEvidence, MedEntry, Alert, and similar.
12. **Tests with pytest:**
    * One unit test per pure function, including the empty case.
    * Regression tests pinning known-good output.
    * Test functions get the three-line docstring too.
13. Return complete files, never fragments, unless I ask for a diff. No commented-out code. No TODO stubs.
14. **No AI attribution anywhere. Claude and Anthropic must never appear anywhere in the repo:**
    * not as a contributor
    * not in commit messages or trailers (no `Co-authored-by`)
    * not in code, comments, docstrings, file headers, README text, or docs
    * The only exception is my own write-up files, which you never edit.
15. **Enforce these rules with tests, from the first commit:**
    * `tests/test_style.py` parses every file in `src/` and `tests/` with `ast`. It fails if any function lacks a docstring of exactly three non-empty lines where line 1 starts with "Takes" and line 3 starts with "Gives."
    * The same test fails if any parameter or return lacks a type hint, if any `except` is bare or catches `Exception`, or if any parameter shadows a builtin listed above.
    * `tests/test_no_attribution.py` fails if "Claude" or "Anthropic" appears in any file you create or edit.
16. If available, read `/mnt/skills/user/modular-code-standards/SKILL.md` and its `references/refactor-audit.md` before writing or refactoring code.

---

## 9. Repo rules and layout

### 9.1 Target repo

My public INLS 509 repo: https://github.com/AidanColvin/AIDANCOLVIN_aidancol_INLS_509_Mini_Search_Engine_Project_Controlled_Vocab

Clone it. Create the work branch `build/rx-label-search` from `main`. All work happens on that branch. It holds:

* `notes/` and `rubrics/`
* my Part 1 and Part II write-ups, either at the root or moved to `part1_document_collection/` and `part2_controlled_vocabulary/`
* `LICENSE` (MIT)
* `README.md`

Read the repo's current README and file list first, and keep whatever is there.

### 9.2 Read-only

Never edit, move, rename, or delete:

* `notes/` and `rubrics/`
* `LICENSE`
* any write-up `.md` file
* any git tag, such as `part1-submitted`

### 9.3 Earlier code

Earlier build sessions pushed code to my private repo `AidanColvin/AidanColvin-INLS_509_Mini_Search_Engine_Project_Controlled_Vocab_2`. That code uses an older vocabulary (RX01 to RX11) and a one-class scope.

* Reuse it only if I provide it, and only after bringing it up to these standards.
* Never carry over RX01 to RX11.

### 9.4 Layout (build exactly this; propose changes only in Phase 0 with a reason)

```
README.md                         extend; never remove existing content
LICENSE                           read-only
DATA_SOURCES.md                   new
pyproject.toml                    new
.gitignore                        new or extended: data/raw/, data/build/, .venv/, __pycache__/, .pytest_cache/
notes/                            read-only
rubrics/                          read-only
part1_document_collection/        read-only (if present)
part2_controlled_vocabulary/      read-only (if present)
src/rx_label_search/
    __init__.py
    __main__.py                   calls cli.main only
    cli.py                        argument parsing and dispatch only; no logic
    records.py                    frozen dataclasses
    storage/                      read_json.py, write_json.py, read_jsonl.py, write_jsonl.py (I/O only)
    collect/                      fetch.py (I/O), filters.py (pure), dedupe.py (pure), stats.py (pure)
    text/                         fields.py, sentences.py, negation.py, html_tables.py
    normalize/                    ingredients.py, rollup.py, rxnorm_client.py (I/O), name_dictionary.py, name_matcher.py, med_line_parser.py
    vocabulary/                   terms.py (T01-T17 metadata), safety.py, route.py, population.py, patient_info.py, dosing.py, dea.py, product.py, interaction.py, hierarchy.py, tagger.py
    search/                       tokenize.py, index.py, bm25.py, facets.py, snippets.py, query.py
    interactions/                 evidence.py, tiers.py, groups.py, pairs.py, duplicates.py, checker.py, report.py
    evaluate/                     gold.py, tag_metrics.py, ir_metrics.py, report.py
    serve/                        api_search.py, api_check.py (Phase 7)
data/
    reference/                    committed: fda_enzyme_table.json, onc_high_priority_pairs.json, active_metabolites.json (each with source URL and access date)
    gold/                         committed: my hand labels
    raw/                          gitignored
    build/                        gitignored
tests/
    fixtures/                     committed: small real openFDA label JSON for test drugs, each with fetch date
    test_style.py
    test_no_attribution.py
    mirrors src/ one test file per module
.github/workflows/                Phase 7 only
```

### 9.5 Git rules

* Work on `build/rx-label-search` only. Never commit directly to `main` during the run.
* Commit after every completed module with a plain, specific message in the imperative mood, such as `Add openFDA bulk download`. Write the message to a temp file and commit with `git commit -F <file>`, so no tool adds text to it.
* Push the work branch after every commit: `git push -u origin build/rx-label-search`.
* Never force-push. Never rewrite pushed history. Never move or delete tags. Rewriting an unpushed local commit message to remove attribution (item below) is allowed.
* Never commit secrets. `VERCEL_TOKEN` lives in GitHub repo secrets, and I add it myself.
* Never commit raw or built data. Commit only code, reference files, gold placeholders, small fixtures, and reports.
* **Attribution scrub, required before every push:**
  1. In Phase 1, before the first commit, add `.githooks/commit-msg` (committed) and run `git config core.hooksPath .githooks` (local only). The hook deletes any commit-message line that starts with `Co-Authored-By:`, contains `noreply@`, starts with `Generated with`, or matches `^[A-Za-z]+-Session: https://`. Write the hook's patterns so that the two forbidden names in Section 8 item 14 do not appear literally in the hook file.
  2. Before every push, run `git log --format=%B origin/build/rx-label-search..HEAD` and check it with the same patterns plus a case-insensitive search for the two forbidden names. If any line matches, fix the unpushed commit messages with `git commit --amend` or an interactive rebase of unpushed commits only, then push.
  3. Never create `CLAUDE.md`, `AGENTS.md`, or a `.claude/` directory inside the repo. If a tool creates `.claude/`, delete it before committing. Do not add these names to `.gitignore`, because the name itself would then appear in the repo.
  4. `tests/test_no_attribution.py` builds its forbidden strings by joining fragments (for example `"Cla" + "ude"`), so the test file itself passes. It scans every tracked file and fails on a case-insensitive match.
* **At the end of Phase 7:** merge `build/rx-label-search` into `main` with a fast-forward or a normal merge commit and push `main`. If the push to `main` is blocked, write `reports/MERGE_READY.md` with the exact merge and push commands, and stop.

### 9.6 Fixtures

Save real openFDA label JSON, with fetch date, for:

* olanzapine
* the Adderall mixed amphetamine salts
* zolpidem
* trazodone
* desvenlafaxine
* venlafaxine
* cyclobenzaprine
* pregabalin
* OxyContin (oxycodone extended-release)
* gabapentin
* Entresto (sacubitril and valsartan)
* a dextroamphetamine-only product

Tests run offline against these fixtures.

### 9.7 Docs

* **README.md:** add a "Tool" section covering what it does, how to run each CLI command, the notice text, and the build date. Extend the Files table. Keep all existing content.
* **DATA_SOURCES.md:** each source's URL, license or terms, what it is used for, and the fetch or access date.

---

## 10. Build phases

Run every phase in order, end to end, without stopping. Within a phase: write, test, fix, commit, push. At the end of each phase, write the phase report (Section 11) and start the next phase.

A phase is "done" when its done-criteria pass. If a criterion cannot be met after real effort, apply Section 0.2 item 5, record the gap in the phase report, and continue. Never skip a phase.

### Phase 0: Audit and plan (writes files, does not stop)

* Clone the repo, create `build/rx-label-search`, list every file, and record which paths are read-only under Section 9.2.
* Write `pyproject.toml` (package `rx_label_search`, Python 3.11+, `pytest` as the only dependency, `src/` layout).
* Verify, with web fetches, and record in `reports/VERIFIED_FACTS.md`: the openFDA download manifest URL and label file layout; the label fields named in Section 4.3; the RxNorm endpoints you will call; the DailyMed setid URL pattern; Vercel's current Python function limits.
* Write `reports/phase0_audit.md` with the file list, the verified facts, anything unverifiable, and the final layout. Commit and push. Continue.

### Phase 1: Collect

* Write `tests/test_style.py` and `tests/test_no_attribution.py` first, and the commit-msg hook (Section 9.5).
* Fetch the openFDA manifest and bulk label files. These are I/O-only functions.
* Stream-process the files: apply the filters, de-duplicate, and write:
  * `data/build/collection.jsonl`
  * `data/build/collection_stats.json`, with counts after each filter
  * the name dictionary
* Save the fixtures in Section 9.6, each with its fetch date.
* **Done when:**
  * every kept label has an `openfda` object and the Rx product type
  * there is one label per ingredient set
  * the counts are reported
  * all tests pass

### Phase 2: Normalize and parse

* Build ingredient sets, base-ingredient rollup, the active-metabolite reference file, the name matcher, and the medication-line parser.
* **Done when:**
  * my test input (Section 3.1) parses into the seven expected entries with correct daily totals
  * typos resolve with the mapping shown
  * ambiguous names come back "needs confirmation"
  * unparseable text lands in "Unresolved entries"
  * all tests pass

### Phase 3: Tag

* Build all 17 rule functions, the hierarchy expansion, evidence capture, negation, and the parallel tagger with its cache.
* **Done when:**
  * the fixture tests match Appendix C's examples: OxyContin carries at least T01, T02, T05, T07, T08, T09, T10, T13, and T15; cyclobenzaprine carries T14 and T15; gabapentin carries T06 but not T01; Entresto carries T09 but not T08
  * the consistency tests pass
  * all tests pass
* Where a fixture label disagrees with an expected value, the label wins. Record the difference in the phase report and write the test to match the label.

### Phase 4: Evaluate tagging

* Build a gold-set template and a small CLI I will use to record my own hand labels, per label and per term, with a rationale.
* Create `data/gold/gold_sample_PLACEHOLDER.json` with obviously fake values, used only to prove the harness runs. You never write real gold labels.
* Compute per-term precision, recall, and F1, with confusion counts, and write a report.
* **Done when** the harness runs on the placeholder file, the README explains how I fill in the real gold set, and all tests pass.

### Phase 5: Search

* Build the index, BM25, facets, snippets, the query CLI, and the IR evaluation harness (Section 7).
* **Done when** Scenarios 1 to 3 pass on fixtures and all tests pass.

### Phase 6: Check

* Build group alerts, pair alerts, duplication flags, tiers, the report format (Section 3.5), and the check CLI.
* **Done when:**
  * the Section 3.6 acceptance test passes, with any label-driven differences recorded in the phase report
  * every ONC high-priority pair whose drugs are both in the collection fires
  * all tests pass

### Phase 7: Serve

* **Vercel project:** `rx-label-search`, under my team `aidancolvins-projects`.
* **Architecture:** one Python implementation. The page calls stateless Python functions: `api_search` and `api_check`.
* **No second implementation** of the checker in the browser. Two copies of the logic would drift apart.
* **Function size:** compare the built index against the Vercel limits you verified in Phase 0. If the index does not fit, split it into per-ingredient shards loaded on demand, and record the decision.
* **Front end:** a thin static page with:
  * a search box and PDLA filters
  * a medication-list box
  * the Section 3.5 output
  * the notice text and build date
* Clean, Apple-like visual polish waits for the Part 3 rubric.
* **Weekly GitHub Actions workflow** at `.github/workflows/rebuild.yml`: on a weekly schedule and on push to `main`, rebuild the collection, tags, and index from openFDA, run all tests, and deploy to Vercel only if the tests pass and `VERCEL_TOKEN` is present. If the secret is missing, the workflow skips the deploy step and says so in its log.
* Test the page locally against the Python functions before the merge.
* **Done when** the page runs locally, the workflow file is valid, and all tests pass. Then merge to `main` per Section 9.5.

---

## 11. Reports (this replaces talking to me)

Write these files under `reports/` in the repo and commit them with the code:

* `reports/phase0_audit.md` through `reports/phase7_serve.md`, one per phase, each with:
  1. What was built, in five lines or fewer.
  2. The commands run and the test results, with pass, fail, and skip counts.
  3. Commits made and the push result.
  4. Any expected value that a label contradicted, and what the test now asserts.
  5. What I should check by hand.
  6. Open questions.
* `reports/VERIFIED_FACTS.md`: every fact checked against official docs, with URL and date.
* `reports/OPEN_QUESTIONS.md`: every ambiguity, the choice made, and the alternatives.
* `reports/BLOCKERS.md`: every skipped test and every hard blocker, with tracebacks and next steps.
* `reports/FINAL_REPORT.md`: the state of every phase against Section 13, how to run each CLI command, and the first three things I should do when I return.

Plain English, short sentences. No preamble, no praise, no summary of what you just said.

---

## 12. End of session

The `reports/` folder is the session record. Before the final push:

* Zip `reports/`, `README.md`, `DATA_SOURCES.md`, and a copy of this prompt into `reports/bundle_<YYYY-MM-DD>.zip` so I can drop it into my project programs folder.
* Commit and push the bundle with the final report.

---

## 13. Definition of done (whole project)

* All 17 PDLA terms are tagged with evidence, and the consistency tests pass.
* The per-term precision, recall, and F1 harness runs, and the README explains how I record the real gold set.
* The ONC floor passes for every pair present in the collection.
* The Section 3.6 acceptance test passes.
* Scenarios 1 to 3 pass.
* The page runs locally against the Python functions, and the weekly workflow deploys to Vercel on merge to `main` when the tests pass and the secret is present.
* README.md and DATA_SOURCES.md are complete.
* The style, attribution, and all other tests pass, with every skipped test listed in `reports/BLOCKERS.md`.
* The two forbidden names in Section 8 item 14 appear nowhere in the repo, including commit messages.
* `reports/FINAL_REPORT.md` is committed and pushed, and `main` has the merge or `reports/MERGE_READY.md` says how to do it.

---

## Appendix A: My goals and requirements, word for word

These are my messages as I wrote them, typos included. They state what I want this tool to be. Read them as requirements.

<my_goals_verbatim>

**Message 1:**

if i want a MD acurate upto date but FREE open acess open source and i want to build a tool that MD or anyone in us can use to check prescription drug to drug interactions should i pull from numropus or just openFDA `drug_interactions like im wanting to build this search endigin tool`

**Message 2:**

so how can i take what i have and expand this i am, trying to build a acuracte opensource MD levle perscription drug to drug inteaction tool that is open spoucre free open acess can be hosted free on public webprogram that is open aviblie as a a github repo and i can have for my project for my search enginen class this semsester

**Message 3:**

i dont want it to be limited to just one drug class the goal is a MD can input a patients meds for exzample 10 mg Zyprexa X 1 daily , 20 mg adderall X 3 daily , 10 mg ambien X daily , trazdone 50 mg X 1 daily , desvenlafaxine 50 mg X 1 daily , Flexril 10 mg X 3 times daily , Lyrica 100 mg X 3 daily
I want to see drug to drug inteactions class of drug all varibles i talked about in my part 2 assinment and the the [generic name](https://www.forhers.com/drugs/compare/desvenlafaxine-vs-venlafaxine#:~:text=Desvenlafaxine,work%20the%20same%20way%2C) (the active medicinal ingredient

**Message 4:**

So for this project, I guess the first question I have is: should I do this if I'm really wanting to do it as my search engine class project, you know, my semester project? Should I do this in Python or C or C++ or Java or a mix of all of them? Additionally, if I don't have the rubric for part three, which is the next portion of this project, but I know it's gonna be a search engine, I know it's gonna follow in line with part one and two, which we have been working on, and I know that I want this to be accurate, something that can be used by doctors in the US, and I want it to be open source, open access, it to be free and accessible by anyone as a free website or free web program, maybe through Versal, what are the next steps? Should I start coding? Should I focus on the backend? Should I focus on the front end? etc

**Message 5:**

So for this project, before I go into having you generate a lot of my Python code and working on the backend, what I wanna have happen is for you to strengthen my prompt in order to strictly and accurately follow what I want you to do. So if you can make this prompt a lot better, I'm gonna provide you with what I have so far as well as kind of how I like my code and some example code as well as for context, of course the part one and part two. Can you strengthen this prompt for me?


So, to be clear, take all of this information and give me a very strong, very clear, very expansive, robust, strict, better prompt that I can then give you to execute, rather than execute automatically
So I want to have this, you know, based on my part one and part two, which I'm gonna share not a different version, and additionally, I think we're losing scope of the value of this tool, which is going to be hit on all these parts, serve as a search engine, serve as a tool to see interactions, and then also serve as a tool to categorize and tag interactions of these prescription drug drug interactions, ideally predominantly using that FDA source, given that and it may be best to start with the back end, and this has a very large scope and a very big goal, and I don't want it, you know, limited to something where it's you can only search based on like drug class, right, because that's not useful. You wanna have it where you can put in a large amount of prescription medications, flag them, categorize them, rate them, and then have this kind of dynamic live up-to-date open access, open source free webpage that's connected to this pretty robust back end. can we start working on that Python code and further can we have it so that it fits into this GitHub project and repo, 

remember for this Python code it needs to be very strict in terms of having a function do one specific thing, right? We want a ton of simple functions, so each function has one specific job, and they work together, you know, to do goals, so it's just one specific thing, and these specific things come together to do a job, and then these jobs come together for the program, so it's really modular. It's a lot of basic simple functions rather than these complex functions, but simpler modular Python functions that are reliable and work together and only do one specific thing. additionally for my doc strings for each function, each function needs to have a doc string, so you'll have the function header, right? you know, define XYZ, then underneath it you're gonna have the"""four line one and within line one you're going to say specifically, what does this take? So what are the inputs for the function?
line 2 will be what does the function do, right so what does it do? We take what we got from line one, so the function takes these inputs. It does this thing, you know, transforms this thing
line 3 this is going to indicate what are the outputs, what it gives
And all of these should be clear, simple, plain English, so each function has a three-line doc string, and they should follow that order

**Message 6:**

Can you within the prompt also, you know, I think you're skimming over some of the information and losing and truncating some of the information. I also really want within this prompt you to word forward include, you know, part one and part two and the goals. I'm really worried that you're going to generate something that isn't necessarily meeting the high standards I need, and I need it to fit into this GitHub repo in this project and strictly following my style, so give me an updated prompt

</my_goals_verbatim>

**Reading notes:**
* "flag them, categorize them, rate them" maps to Section 3.5: alerts (flag), the medication table and PDLA tags (categorize), and tiers (rate).
* "dynamic live up-to-date" maps to the weekly rebuild and the build date in Section 10, Phase 7.
* "four line" in Message 5 is settled by Appendix D: exactly three docstring lines.

---

## Appendix B: Part 1 (Revised), word for word

This defines the collection. Section 2 of this prompt implements its filters.

<part1_revised_verbatim>

# Aidan Colvin aidancol
# Mini Search Engine Project, Part 1 (Revised): Document Collection Foraging
Last Updated 09-21-2026

**Source:** [FDA Drug Labels](https://open.fda.gov/apis/drug/label/)

#### What the Collection Is About

These are FDA drug labels: the prescribing information that comes with a medication. Each record is one version of one label, submitted to FDA in Structured Product Labeling (SPL) format. One label can cover several products and package sizes (NDCs).

The main text sits in these fields:

* `indications_and_usage`: What the drug treats
* `adverse_reactions`: Side effects
* `warnings_and_cautions` (newer, PLR-format labels) or `warnings` (older labels): Precautions and risk information
* `boxed_warning`: The most serious risks, when the label has a boxed warning
* `contraindications`: Situations, and other drugs, the product must not be used with
* `drug_interactions`: How the drug interacts with other drugs and foods, and how to manage it

Most records also carry structured attributes in an `openfda` object:

* `brand_name`
* `generic_name`
* `substance_name`
* `route`
* `pharm_class_epc`
* `application_number`

openFDA adds the `openfda` object only when applicable, so some labels lack it. Dosage form is described in text, in `dosage_forms_and_strengths`.

#### Who Will Search It

* Pharmacists and their supporting staff
* Healthcare providers (including doctors, nurses, and clinical staff)
* Patients and family members

A central question for all three groups is whether a patient's medications are safe to take together.

#### Document Count & Scope Filtering

**Does it contain more than 50 documents?**
Yes. The Label endpoint holds 262,883 labels as of its September 18, 2026 update, prescription and over-the-counter combined. Human prescription labels are a large subset, about 54,000 by my Part 1 estimate.

To narrow down the dataset, the collection will be filtered by:

1. Keeping human prescription labels only (`openfda.product_type` is HUMAN PRESCRIPTION DRUG).
2. Keeping labels that have the `openfda` object, since the system needs its ingredient names and identifiers to match the same drug across labels.
3. Retaining only the newest label per active-ingredient set. A combination product counts as its own ingredient set, so combinations stay in the collection.

**Why not one drug class:** My original Part 1 restricted the collection to a single drug class. Interactions often cross classes, such as an antidepressant taken with a muscle relaxant, so a one-class collection would miss the combinations users most need to find.

**AI use:** My original Part 1 used AI only for spelling, grammar, and phrasing. For this revision, I decided to widen the scope to all drug classes. I used Claude (Anthropic) to check my field names against the openFDA Label documentation and to draft the revised field descriptions and scope filters.

</part1_revised_verbatim>

---

## Appendix C: Part II, Mini Controlled Vocabulary (PDLA, 17 terms), word for word

This is the specification for the tagger (Section 6), the hierarchy (Section 6, item 4), the search scenarios (Section 7), and the interaction terms (Section 3). Implement every rule exactly as written here.

<part2_verbatim>

# Aidan Colvin aidancol
# Mini Search Engine Project, Part II: Mini Controlled Vocabulary
Last Updated 09-21-2026

**Help received:** UPDATE ADD BEFORE SUBMITTING  --> If you received help from anyone, give them credits by listing their name(s) on the top of your submission. 

---

## 1. Terms and definitions [50 points]

**Vocabulary name:** Prescription Drug Label Attributes (PDLA)

PDLA tags the label properties that pharmacists, clinicians, and patients filter on: safety signals, route, patient group, dosing, DEA control, product form, and drug interaction risk. Each term is assigned by a fixed rule over named openFDA fields, so the same label always gets the same terms. The interaction-risk terms (T13 to T17) also drive the planned interaction checker: when two drugs on a patient's medication list share one of these terms, the checker flags them together.

Two rules apply to every term:

* If a field a rule needs is missing, do not assign the term.
* A missing term means the label or its openFDA record did not show the condition. It does not prove the opposite.

### Overview

| ID | Preferred name | Property | Hierarchy | Fields used |
| :--- | :--- | :--- | :--- | :--- |
| T01 | Boxed Warning | Safety signal | Top level | `boxed_warning` |
| T02 | Oral Route | Route | Top level | `openfda.route` |
| T03 | Pediatric Indication | Patient group | Top level | `indications_and_usage`, `pediatric_use` |
| T04 | High-Frequency Adverse Effect | Safety signal | Top level | `adverse_reactions`, `adverse_reactions_table` |
| T05 | Medication Guide | Patient information | Top level | `spl_medguide` |
| T06 | Renal Dose Adjustment | Dosing | Narrower term under T11 | `dosage_and_administration`, `use_in_specific_populations`, `precautions` |
| T07 | Controlled Substance | DEA control | Top level; broader term over T10 | `controlled_substance` |
| T08 | Single Active Ingredient | Product form | Top level | `openfda.substance_name` |
| T09 | Brand Name Product | Product form | Top level | `openfda.brand_name`, `openfda.generic_name`, `openfda.application_number` |
| T10 | Schedule II Controlled Substance | DEA control | Narrower term under T07 | `controlled_substance` |
| T11 | Organ Impairment Dose Adjustment | Dosing | Top level; broader term over T06 and T12 | Assigned through T06 and T12 |
| T12 | Hepatic Dose Adjustment | Dosing | Narrower term under T11 | `dosage_and_administration`, `use_in_specific_populations`, `precautions` |
| T13 | Interaction Risk | Interaction risk | Top level; broader term over T14 to T17 | Assigned through T14 to T17 |
| T14 | Serotonin Syndrome Risk | Interaction risk | Narrower term under T13 | `boxed_warning`, `warnings_and_cautions`, `warnings`, `precautions`, `drug_interactions`, `contraindications` |
| T15 | CNS Depression Risk | Interaction risk | Narrower term under T13 | `boxed_warning`, `warnings_and_cautions`, `warnings`, `precautions`, `drug_interactions` |
| T16 | QT Prolongation Risk | Interaction risk | Narrower term under T13 | `boxed_warning`, `warnings_and_cautions`, `warnings`, `precautions`, `drug_interactions`, `contraindications` |
| T17 | Contraindicated Combination | Interaction risk | Narrower term under T13 | `contraindications` |

### Term definitions

#### T01: Boxed Warning

* **ID:** T01
* **Preferred name:** Boxed Warning
* **Definition:** The label carries an official FDA boxed warning. This is the boxed statement at the top of the prescribing information that flags risks that can cause death or serious injury.
* **Assign when:** `boxed_warning` has text.
* **Do not assign when:** a serious risk appears only in `warnings_and_cautions` or `warnings` with no box.
* **Alternative names:** Black Box Warning, BBW, FDA Boxed Warning
* **Useful for:** finding the drugs with the most serious labeled risks.

#### T02: Oral Route

* **ID:** T02
* **Preferred name:** Oral Route
* **Definition:** The drug is taken by mouth.
* **Assign when:** the harmonized `openfda.route` field includes ORAL, even if other routes are also listed.
* **Do not assign when:** no listed route is ORAL, such as injectable, topical, ophthalmic, or inhaled products. Sublingual and buccal are separate routes in FDA's route list, so they do not get this term.
* **Alternative names:** Oral Administration, By Mouth, Per Os (PO)
* **Useful for:** patients and caregivers who want tablets, capsules, or liquids taken by mouth.

#### T03: Pediatric Indication

* **ID:** T03
* **Preferred name:** Pediatric Indication
* **Definition:** The label says the drug is safe and effective for at least one pediatric age group. For prescription drug labeling, FDA generally defines pediatric patients as birth to 16 years, meaning younger than 17.
* **Assign when:** `indications_and_usage` names pediatric patients for at least one indication, or `pediatric_use` states that safety and effectiveness have been established in a pediatric age group.
* **Do not assign when:** the label states that pediatric safety and effectiveness have not been established; the label contraindicates use in children; or the label gives pediatric study or drug-level data but no established use. A statement such as "not established in patients younger than 12" does not qualify by itself, because it does not say use was established at any pediatric age. Approval that starts at age 17 is adult approval under FDA's definition.
* **Alternative names:** Pediatric Approval, Approved for Children, Children's Usage
* **Not alternative names:** "Pediatric Use" and "Pediatric Safety." Pediatric Use is the label section that also holds "not established" statements, so it would match labels this term excludes.
* **Useful for:** pediatric clinicians and parents looking for drugs labeled for children.

#### T04: High-Frequency Adverse Effect

* **ID:** T04
* **Preferred name:** High-Frequency Adverse Effect
* **Definition:** At least one adverse reaction occurred in 10% or more of patients taking the drug in a clinical trial reported on the label. The 10% cutoff is the "very common" band (1 in 10 or more) in the CIOMS III frequency categories used in EU product labeling. US labels report percentages rather than these band names, so the cutoff is applied to the reported percentages.
* **Assign when:** `adverse_reactions` or `adverse_reactions_table` reports 10% or more for any reaction in the drug group of a clinical trial. The placebo rate does not change the decision.
* **Do not assign when:** every reported rate is below 10%; reactions come only from postmarketing reports with unknown frequency; or the label lists reactions without percentages.
* **Alternative names:** Very Common Side Effects, Very Common Adverse Reactions, High-Incidence Side Effects
* **Not alternative names:** "Common Side Effects" and "Frequent Side Effects." In CIOMS III, common and frequent both mean 1% to under 10%.
* **Useful for:** patients and prescribers weighing how likely side effects are before starting a drug.

#### T05: Medication Guide

* **ID:** T05
* **Preferred name:** Medication Guide
* **Definition:** The label includes an FDA Medication Guide. This is a plain-language patient handout that FDA requires for certain drugs with serious risks. Under 21 CFR Part 208, it must be given to the patient when the drug is dispensed.
* **Assign when:** `spl_medguide` has text.
* **Do not assign when:** the only patient material is a patient package insert (`spl_patient_package_insert`) or patient counseling text. These are different documents.
* **Alternative names:** MedGuide, Med Guide, FDA Medication Guide
* **Useful for:** pharmacists who must hand out the guide at pickup, and patients who want a plain-language summary of a drug's main risks.

#### T06: Renal Dose Adjustment

* **ID:** T06
* **Preferred name:** Renal Dose Adjustment
* **Broader term:** T11: Organ Impairment Dose Adjustment
* **Definition:** The label gives specific dosage modifications for patients with renal impairment.
* **Assign when:** dosing text in `dosage_and_administration`, `use_in_specific_populations`, or `precautions` (older-format labels) ties a kidney function level to a lower dose, a longer time between doses, or a lower maximum dose. Kidney function levels include creatinine clearance or eGFR ranges; mild, moderate, or severe renal impairment; and dialysis.
* **Do not assign when:** the label gives general warnings about kidney toxicity with no dose change; the label says no dose change is needed; or the label only says to avoid the drug, or that it is contraindicated, below a kidney function level. That tells the user not to use the drug, not how to dose it.
* **Alternative names:** Kidney Dose Adjustment, Renal Dosing, Renal Impairment Dosing
* **Useful for:** pharmacists and prescribers dosing patients with chronic kidney disease.

#### T07: Controlled Substance

* **ID:** T07
* **Preferred name:** Controlled Substance
* **Definition:** The DEA controls the drug under the Controlled Substances Act because of its potential for abuse or dependence.
* **Assign when:** `controlled_substance`, the Controlled Substance subsection of the label, names DEA Schedule II, III, IV, or V.
* **Do not assign when:** `controlled_substance` is missing or says the drug is not scheduled; or the label discusses abuse or dependence in `drug_abuse_and_dependence`, `abuse`, or `dependence` but names no schedule.
* **Field note:** `openfda.pharm_class_cs` is not used. "CS" there means chemical structure, not controlled substance.
* **Alternative names:** Scheduled Drug, DEA Scheduled, Controlled Medication
* **Useful for:** pharmacists handling storage, record-keeping, and refill rules, and prescribers screening for abuse risk.

#### T08: Single Active Ingredient

* **ID:** T08
* **Preferred name:** Single Active Ingredient
* **Definition:** The product contains exactly one active ingredient.
* **Assign when:** `openfda.substance_name` has exactly one entry. A salt form counts as one ingredient, since it appears as one entry, such as METFORMIN HYDROCHLORIDE.
* **Do not assign when:** the field has two or more entries, meaning a combination drug such as sacubitril and valsartan.
* **Alternative names:** Single-Ingredient Product, Single-Entity Drug
* **Not an alternative name:** "Monotherapy." It means treating a patient with one drug, not a product with one ingredient. A single-ingredient drug can still be part of combination therapy.
* **Useful for:** separating plain products from combination products when checking a patient's drug list for duplicate ingredients.

#### T09: Brand Name Product

* **ID:** T09
* **Preferred name:** Brand Name Product
* **Definition:** The product is sold under a proprietary trademarked name rather than its generic name.
* **Assign when:** `openfda.brand_name` differs from `openfda.generic_name` (ignoring case).
* **Do not assign when:** `brand_name` repeats the generic name, or `openfda.application_number` starts with ANDA, the approval pathway for generics. If `application_number` is missing, the name check decides.
* **Why the name check:** openFDA copies `brand_name` from the proprietary name in the NDC Directory, and some products list their generic name there. A filled `brand_name` alone does not prove a trademark.
* **Alternative names:** Proprietary Drug, Trade Name, Branded Medication
* **Useful for:** users who know a drug only by its brand name, and anyone comparing brand and generic labels.

#### T10: Schedule II Controlled Substance

* **ID:** T10
* **Preferred name:** Schedule II Controlled Substance
* **Broader term:** T07: Controlled Substance
* **Definition:** The DEA places the drug in Schedule II, the most restricted schedule for drugs with an accepted medical use. Examples include oxycodone, fentanyl, and amphetamine.
* **Assign when:** `controlled_substance` names Schedule II (CII).
* **Do not assign when:** the schedule is III, IV, or V.
* **Alternative names:** C-II, CII, Schedule 2
* **Useful for:** pharmacists and patients, since Schedule II prescriptions cannot be refilled.

#### T11: Organ Impairment Dose Adjustment

* **ID:** T11
* **Preferred name:** Organ Impairment Dose Adjustment
* **Narrower terms:** T06: Renal Dose Adjustment, T12: Hepatic Dose Adjustment
* **Definition:** The label gives specific dosage modifications for patients with reduced kidney or liver function.
* **Assign when:** the label gets T06 or T12. T11 has no rule of its own.
* **Do not assign when:** the dose change is for another reason, such as age, weight, or a drug interaction, or for another organ, such as the heart.
* **Alternative names:** Organ Function Dose Adjustment, Kidney or Liver Dose Adjustment
* **Useful for:** one filter that answers whether a drug needs a dose change when the kidneys or liver are impaired.

#### T12: Hepatic Dose Adjustment

* **ID:** T12
* **Preferred name:** Hepatic Dose Adjustment
* **Broader term:** T11: Organ Impairment Dose Adjustment
* **Definition:** The label gives specific dosage modifications for patients with hepatic impairment.
* **Assign when:** dosing text in `dosage_and_administration`, `use_in_specific_populations`, or `precautions` (older-format labels) ties a liver function level to a lower dose, a longer time between doses, or a lower maximum dose. Liver function levels include Child-Pugh class A, B, or C, and mild, moderate, or severe hepatic impairment.
* **Do not assign when:** the label warns about liver injury but gives no dose change; the label says no dose change is needed; or the label only says to avoid the drug, or that it is contraindicated, at a liver function level.
* **Alternative names:** Liver Dose Adjustment, Hepatic Dosing, Hepatic Impairment Dosing
* **Useful for:** dosing patients with cirrhosis or other liver disease.

#### T13: Interaction Risk

* **ID:** T13
* **Preferred name:** Interaction Risk
* **Narrower terms:** T14: Serotonin Syndrome Risk, T15: CNS Depression Risk, T16: QT Prolongation Risk, T17: Contraindicated Combination
* **Definition:** The label warns that combining the drug with other drugs can cause serious harm of at least one type named in T14 to T17.
* **Assign when:** the label gets T14, T15, T16, or T17. T13 has no rule of its own.
* **Do not assign when:** the label's interaction text covers only other effects, such as changes in drug levels through liver enzymes, with none of the four risk types. Those interactions still appear in keyword search of `drug_interactions`.
* **Alternative names:** Drug Interaction Warning, DDI Risk, Interaction Warning
* **Useful for:** one filter that finds every label warning of a serious combination risk.

#### T14: Serotonin Syndrome Risk

* **ID:** T14
* **Preferred name:** Serotonin Syndrome Risk
* **Broader term:** T13: Interaction Risk
* **Definition:** The label warns that the drug can contribute to serotonin syndrome, a potentially life-threatening reaction to excess serotonin activity, most often when it is combined with other serotonergic drugs.
* **Assign when:** `boxed_warning`, `warnings_and_cautions`, `warnings`, `precautions`, `drug_interactions`, or `contraindications` names serotonin syndrome or serotonin toxicity as a risk of this drug.
* **Do not assign when:** serotonin appears only in `mechanism_of_action`, `clinical_pharmacology`, or `pharmacodynamics`, with no stated risk.
* **Alternative names:** Serotonin Toxicity Risk, Serotonergic Interaction Risk
* **Useful for:** catching stacked serotonergic drugs on one medication list, such as an antidepressant plus a muscle relaxant.

#### T15: CNS Depression Risk

* **ID:** T15
* **Preferred name:** CNS Depression Risk
* **Broader term:** T13: Interaction Risk
* **Definition:** The label warns that combining the drug with other central nervous system (CNS) depressants, such as opioids, benzodiazepines, sleep medicines, or alcohol, can add sedation or slow breathing.
* **Assign when:** `boxed_warning`, `warnings_and_cautions`, `warnings`, `precautions`, or `drug_interactions` warns of added CNS depression, sedation, or respiratory depression with other CNS depressants or alcohol.
* **Do not assign when:** drowsiness appears only in `adverse_reactions` as an effect of the drug alone, or the label warns only about driving or operating machinery.
* **Alternative names:** Additive Sedation Risk, CNS Depressant Interaction, Respiratory Depression Interaction Risk
* **Useful for:** catching several sedating drugs on one medication list.

#### T16: QT Prolongation Risk

* **ID:** T16
* **Preferred name:** QT Prolongation Risk
* **Broader term:** T13: Interaction Risk
* **Definition:** The label warns that the drug prolongs the QT interval, a delay in the heart's electrical recovery that can lead to a dangerous rhythm called torsades de pointes, or it advises against combining the drug with other QT-prolonging drugs.
* **Assign when:** `boxed_warning`, `warnings_and_cautions`, `warnings`, `precautions`, `contraindications`, or `drug_interactions` warns of QT prolongation or torsades de pointes.
* **Do not assign when:** QT appears only in study results that show no clinically meaningful effect, or only in `pharmacodynamics` with no stated warning.
* **Alternative names:** QTc Prolongation Risk, Torsades Risk, QT-Prolonging Drug
* **Useful for:** catching two or more QT-prolonging drugs on one medication list.

#### T17: Contraindicated Combination

* **ID:** T17
* **Preferred name:** Contraindicated Combination
* **Broader term:** T13: Interaction Risk
* **Definition:** The label says the drug must not be used together with at least one named drug or drug class.
* **Assign when:** `contraindications` names a drug or drug class that must not be used with this drug, such as MAO inhibitors or strong CYP3A inhibitors.
* **Do not assign when:** `contraindications` lists only conditions, allergies, or patient groups; or the combination appears only in `warnings` or `drug_interactions` as "avoid" or "not recommended," which is a weaker statement than a contraindication.
* **Alternative names:** Contraindicated Co-Medication, Do-Not-Combine Warning
* **Useful for:** the highest-priority alerts, where the label itself says two drugs must not be combined.

**AI use:** In accordance with class policy, Claude and Gemini were used predominantly in combination with class lectures, slide decks, and assignment content to proofread, correct grammar and spelling, and ensure that thoughts regarding term definitions, descriptions, and synonyms were conveyed clearly and concisely. In a limited capacity, class slides and course material were provided to the AI to pull definitions learned in class, ensuring that course concepts were correctly applied to the terms and combined with original thinking and work for this section.

---

## 2. Organize your vocabulary [10 points]

### 1) Structure of your vocabulary

My vocabulary has relationships. It is a shallow hierarchy, not a flat list: ten top-level terms, with seven narrower terms under three of them. Every link uses one relationship, "is a type of."

* **T01: Boxed Warning**
* **T02: Oral Route**
* **T03: Pediatric Indication**
* **T04: High-Frequency Adverse Effect**
* **T05: Medication Guide**
* **T07: Controlled Substance**
  * **T10: Schedule II Controlled Substance** (is a type of Controlled Substance)
* **T08: Single Active Ingredient**
* **T09: Brand Name Product**
* **T11: Organ Impairment Dose Adjustment**
  * **T06: Renal Dose Adjustment** (is a type of Organ Impairment Dose Adjustment)
  * **T12: Hepatic Dose Adjustment** (is a type of Organ Impairment Dose Adjustment)
* **T13: Interaction Risk**
  * **T14: Serotonin Syndrome Risk** (is a type of Interaction Risk)
  * **T15: CNS Depression Risk** (is a type of Interaction Risk)
  * **T16: QT Prolongation Risk** (is a type of Interaction Risk)
  * **T17: Contraindicated Combination** (is a type of Interaction Risk)

**Relationship definition:**

* **"is a type of":** every label that meets the narrower term's definition also meets the broader term's definition. The narrower term picks out a subset. Schedule II is one of the DEA schedules, so every Schedule II label is a controlled substance label. A renal dose adjustment is one kind of organ impairment dose adjustment, so every T06 label is a T11 label. A serotonin syndrome warning is one kind of interaction risk warning, so every T14 label is a T13 label.

**Two kinds of parent terms:**

The three broader terms work in two different ways.

* **T07: Controlled Substance is an independent parent.** It has its own rule: it is assigned whenever `controlled_substance` names Schedule II, III, IV, or V. T10 marks one subset of those labels, Schedule II. T07's own rule already fires for every Schedule II label, so the T10 link never adds a T07 tag the rule would miss. The link guarantees the two terms stay consistent. Labels in Schedules III to V carry T07 alone.
* **T11: Organ Impairment Dose Adjustment and T13: Interaction Risk are passive containers.** Neither has a rule of its own. T11 is assigned only when T06 or T12 is assigned, and T13 only when at least one of T14 to T17 is assigned. They exist to group their narrower terms for browsing and search. Every T11 label carries T06, T12, or both, and every T13 label carries at least one of T14 to T17.

**Why the top-level terms are not linked:**

Each top-level term describes a different property of a label: a safety signal (T01, T04), patient information (T05), route (T02), patient group (T03), dosing (T11), DEA control (T07), product form (T08, T09), or interaction risk (T13). None implies another. The gabapentin label gives renal dose changes but has no boxed warning. Entresto is a brand product with two active ingredients. A boxed warning can contain an interaction warning, as opioid labels do for benzodiazepines, but many interaction warnings are not boxed, so T13 and T01 stay separate. Linking such terms would tag labels with terms whose definitions they fail.

### 2) Term assignment considerations

**Are the terms mutually exclusive?** No. Documents in this collection can be assigned multiple terms at the same time. The system checks each term's rule on its own and gives a label every term whose definition it meets. For example, the OxyContin (oxycodone extended-release tablets) label meets at least T01, T02, T05, T07, T08, T09, T10, T13, and T15. A label can also carry several interaction-risk terms at once: the cyclobenzaprine label warns of both serotonin syndrome and added CNS depression, so it gets T14 and T15.

**Logical constraints:** No two PDLA terms exclude each other, because each describes a different property of a label. The constraints that do exist come from the hierarchy and from the drugs themselves:

* A label cannot carry T10 without T07, T11 without T06 or T12, or T13 without at least one of T14 to T17.
* A drug product sits in one DEA schedule. So a T07 label either carries T10 or falls in Schedules III to V, never both.

**Does a narrower term bring its broader term?** Yes. If a document receives a narrower term, it automatically receives the broader term. If one searches for a broader term, a document with a narrower term will be returned.

* T10 brings T07. A search for Controlled Substance returns every Schedule II label, along with Schedule III to V labels.
* T06 and T12 bring T11. A search for Organ Impairment Dose Adjustment returns every label with a renal or hepatic dose change.
* T14 to T17 bring T13. A search for Interaction Risk returns every label with any of the four risk types.

This does not work in reverse. A search for T10 does not return Schedule IV labels, a search for T06 does not return labels with only a hepatic dose change, and a search for T14 does not return labels with only a QT warning.

I chose this rule because a user who asks for controlled substances expects the most tightly controlled drugs in the results. Leaving Schedule II labels out of a Controlled Substance search would hide them. The same reasoning applies to Interaction Risk: a user who asks for it expects every serious combination warning, whatever its type.

**How the search engine applies the rule: expansion at indexing time.** Broader terms are added when labels are tagged and indexed, not when a user searches.

1. The tagger runs each term's rule on each label.
2. Each time it assigns a narrower term, it also writes the broader term to that label's index entry. When it detects T06 or T12, it writes T11. When it detects any of T14 to T17, it writes T13. When it detects T10, it writes T07, which T07's own rule has already written.
3. At search time, a query for T11 is a single lookup of the stored T11 tag. It returns the same documents that `T11 OR T06 OR T12` would return under query expansion, because the index already holds every broader tag. A query for T13 works the same way.

I chose indexing over query expansion for three reasons:

* It matches the term definitions. T11 and T13 are defined as assigned when a label gets one of their narrower terms, which is an indexing rule.
* Every stored tag is complete. Facet counts, browsing, and AND or OR combinations work on the stored tags with no rewriting of the user's query.
* The cost is small. If the hierarchy changes, the collection must be re-tagged. The collection keeps one label per active-ingredient set, so a full re-tag fits into the weekly rebuild that follows openFDA's weekly updates.

**How the stored tags drive interaction checks:** When a user enters a medication list, the planned checker compares the stored interaction-risk tags of each drug. Two or more drugs that share T14, T15, or T16 trigger one group alert for that stacked risk, showing each label's warning sentence. A drug with T17 triggers a pair alert only when another drug on the list matches the drug or class named in its contraindications.

**Missing data:**

* Labels with no `openfda` object are excluded by the Part 1 scope filter, since they cannot be matched to an ingredient.
* Inside the collection, if a field a term's rule needs is missing, the system omits the term. It never guesses. For example, a label with an empty `openfda.route` does not get T02, even if its text says the drug is taken by mouth.
* This favors precision over recall. A user who filters on a term gets only labels that meet the term's rule, with no false positives from guessed tags. The cost is some false negatives, so a missing term does not prove the opposite. Keyword search still reaches those labels, since controlled vocabulary search and keyword search work side by side.
* For the interaction-risk terms, a missing tag matters most. A drug without T14 may still add serotonin risk if its label never states it. The checker therefore reports "no warning found in the labels," never "safe."

**AI use:** In accordance with class policy, Claude and Gemini were used predominantly in combination with class lectures, slide decks, and assignment content to proofread, correct grammar and spelling, and ensure that thoughts regarding vocabulary structure, hierarchy, and term assignment rules were conveyed clearly and concisely. In a limited capacity, class slides and course material were provided to the AI to pull definitions learned in class, ensuring that course concepts like flat lists, hierarchies, and mutual exclusivity were correctly applied and combined with original thinking and work for this section.

---

## 3. Example usage of your vocabulary [20 points]

All scenarios search the revised Part 1 collection: human prescription drug labels across all drug classes, one label per active-ingredient set. In the planned search interface, vocabulary terms appear as filters beside the results, grouped by the property they describe in Section 2, such as safety signal, route, dosing, or interaction risk. A user can apply filters to the whole collection or to the results of a keyword search. Scenarios 1 and 2 answer the single-term and two-term cases. Scenario 3 is an additional two-term case that shows the interaction-risk terms.

### Scenario 1: Single-term search

* **Natural language question:** I am a pharmacist checking a new prescription for a patient with severe chronic kidney disease. The patient's creatinine clearance is 25 mL/min. I want to see which drugs in the collection have labels that tell me exactly how to lower the dose or space out doses for patients with impaired kidney function.
* **Selected term:** `T06: Renal Dose Adjustment`
* **How the user applies it:** The user selects Renal Dose Adjustment from the dosing filters. The search engine returns every label that carries the stored T06 tag.
* **Expected documents:** FDA prescription drug labels whose dosing text in `dosage_and_administration`, `use_in_specific_populations`, or `precautions` ties a kidney function level to a lower dose, a longer time between doses, or a lower maximum dose. Kidney function levels include creatinine clearance ranges; mild, moderate, or severe renal impairment; and end-stage renal disease or dialysis. A typical match has a table of doses by creatinine clearance range. Each result would show the drug's brand and generic names and a snippet of its renal dosing text.
* **Not retrieved:**
  * Labels that mention renal excretion or kidney toxicity but give no dose change.
  * Labels that state no dose change is needed in renal impairment.
  * Labels that only say the drug is contraindicated or should be avoided in severe renal impairment, with no adjusted dose.
  * Labels with only a hepatic dose change (T12).
* **Why the term works better than keyword search here:** A keyword search for "renal" or "kidney" also returns labels that mention the kidneys only in pharmacokinetics, adverse reactions, or clinical trial exclusions. Those labels do not answer how to dose this patient, so precision drops. T06 is assigned only when the label ties a kidney function level to a dose change, so every result answers the pharmacist's question as far as the tagging rule is applied correctly.
* **Hierarchy note:** T06 is a type of T11, so the index writes T11 on every T06 label. Each result therefore also carries T11. A user who wanted kidney or liver dose changes would select T11 instead, which returns both T06 and T12 labels.

### Scenario 2: Two-term combination search

* **Natural language question:** My father's doctor plans to start him on a new medication for his high blood pressure. He cannot give himself injections, so it needs to be something he takes by mouth at home. I searched the collection for "hypertension." Before the appointment, I want to narrow those results to the oral options that carry an FDA boxed warning, read those warnings, and bring my questions about them to the doctor.
* **Selected terms:** `T01: Boxed Warning` and `T02: Oral Route`
* **Operator:** **AND**. The search returns only documents that have both Term A (T01) and Term B (T02). In set terms, the result is the intersection of the two tag sets: T01 ∩ T02.
* **How the user applies it:** The user runs the keyword search for "hypertension," then selects Oral Route from the route filters and Boxed Warning from the safety signal filters. The interface joins the two selections with AND and applies them to the keyword results.
* **Expected documents:** FDA prescription drug labels among the keyword results for oral medications, such as tablets, capsules, or oral solutions, that also carry an official boxed warning. Each has ORAL among its routes in `openfda.route` and text in `boxed_warning`. A label that lists ORAL along with another route, such as intravenous, still appears. Brand and generic labels both appear, as do single-ingredient and combination products, since no product-form terms (T08, T09) are selected. These are the labels whose boxed warnings the user reads before the appointment.
* **Not retrieved:**
  * Oral drugs in the results with no boxed warning.
  * Drugs in the results with a boxed warning that are not taken by mouth, such as injection-only, topical, or inhaled products.
  * Sublingual or buccal products, which do not get T02.
  * Labels outside the keyword results.
* **Why AND, not OR:** OR would return the union of the two tag sets, T01 ∪ T02: every oral drug in the results plus every drug in the results with a boxed warning. That adds injection-only drugs with a box, which he cannot take, and oral drugs with no box, which the question does not ask about. OR raises recall for either condition but lowers precision for this question. AND keeps only the drugs that answer both parts.
* **Why the terms work better than keyword search here:** A keyword search for "oral" also matches labels that mention oral contraceptives in drug interactions or oral candidiasis as a side effect, whatever the drug's route. A keyword search for "boxed warning" can miss labels, because the box itself is headed "WARNING" plus its topic, and older labels may never use the phrase "boxed warning." T02 reads the route field and T01 reads the `boxed_warning` field, so neither depends on the label's wording.
* **Hierarchy note:** neither T01 nor T02 has a broader or narrower term, so the hierarchy does not widen or narrow this search.

### Scenario 3 (additional): Two-term interaction-risk search

* **Natural language question:** I am a physician reviewing a patient who takes desvenlafaxine 50 mg daily and trazodone 50 mg at bedtime. Both labels warn of serotonin syndrome, and trazodone is sedating. The patient now reports back spasms, and I am considering a muscle relaxant. I searched the collection for "muscle spasm." Before I prescribe, I want to see which of those drugs carry both a serotonin syndrome warning and a CNS depression warning, because adding one would stack both risks on top of the patient's current medications.
* **Selected terms:** `T14: Serotonin Syndrome Risk` and `T15: CNS Depression Risk`
* **Operator:** **AND**. The search returns only documents that have both Term A (T14) and Term B (T15). In set terms, the result is the intersection of the two tag sets: T14 ∩ T15.
* **How the user applies it:** The user runs the keyword search for "muscle spasm," then selects Serotonin Syndrome Risk and CNS Depression Risk from the interaction risk filters. The interface joins the two selections with AND and applies them to the keyword results.
* **Expected documents:** FDA prescription drug labels among the keyword results whose text warns of serotonin syndrome and of added CNS depression with other depressants or alcohol. The cyclobenzaprine label is one example: it warns of both. These are the options that would stack both risks for this patient.
* **Not retrieved:**
  * Drugs in the results with only one of the two warnings.
  * Drugs in the results with neither warning.
  * Labels outside the keyword results.
* **Why AND, not OR:** OR would return the union, T14 ∪ T15: every result with either warning. That answers a broader question, which drugs add any of these risks. AND isolates the drugs that add both risks at once, which is what this patient's current medications make dangerous.
* **Why the terms work better than keyword search here:** A keyword search for "serotonin" also matches labels that mention serotonin only in the mechanism of action, with no warning. T14 requires a stated serotonin syndrome risk, so it separates a label that warns about the risk from one that only mentions serotonin.
* **Link to the interaction checker:** This search is the manual version of the planned checker. If the physician entered desvenlafaxine, trazodone, and cyclobenzaprine as a medication list, the checker would find T14 on all three labels and raise one serotonin syndrome group alert, showing each label's warning sentence.
* **Hierarchy note:** T14 and T15 are types of T13, so each result also carries T13. Selecting T13 alone would return labels with any of the four interaction-risk types.

**AI use:** In accordance with class policy, Claude and Gemini were used predominantly in combination with class lectures, slide decks, and assignment content to proofread, correct grammar and spelling, and ensure that thoughts were conveyed clearly and concisely. In a limited capacity, class slides and course material were provided to the AI to pull definitions learned in class, ensuring that course concepts were correctly applied and combined with original thinking and work for this section.

---

UPDATE THIS SECTION BEFORE SUBMITTING 

### 4. Peer exchange [20 points]
Invite a peer classmate as a hypothetical user of your search engine.

Describe your planned document collection to them: What documents will be in the collection? Why do you think they are interesting? Also, describe your controlled vocabulary to them: What does each term mean? In what scenarios can they be useful?

Ask the user to come up with a scenario in which they would use your controlled vocabulary when searching or refining results. Ask them to explain their question in complete sentences, and take note of the term(s) they selected.

Answer the following questions:
* <u>What is the name and PID of your user?</u>
* <u>Who invited you as a user to use their search engines (if any)? What are their names and PIDs?</u>
* <u>What was your user's question in natural language?</u>
* <u>What terms did they select to represent that question?</u>

---

</part2_verbatim>

---

## Appendix D: My standing rules, word for word

These rules apply to all work on this project: code, tests, README, DATA_SOURCES.md, commit messages, and replies to me.

<my_rules_verbatim>

STANDING RULES

Accuracy beats speed. Always. Take the time to get it right. Check before you assert. A slow correct answer is what I want; a fast wrong one costs me more than the wait.
If you are not sure, say so and say what would settle it. Never fill a gap with a confident guess.
Never invent a source, a number, a citation, a function, or an API. If you don't have it, say you don't have it.
Use what I've told you before. Don't re-ask what I've already answered.
Tell me when I am wrong, and say why. Do not soften it into a suggestion.
If what I ask for is a bad idea, say so before you build it.

WRITING (chat, emails, messages, papers, assignments)

Plain English. Short sentences. Common words.
Never use a long word where a short one works.
Use a technical term only when it is the correct term and no plain word fits. Never use a term loosely or by feel.
Every word must carry weight. If removing a word leaves the sentence just as clear, it should not have been there.
Every sentence and bullet must earn its place. If cutting it loses nothing, cut it.
Thorough on substance, lean on words. Depth comes from facts and reasoning, not length.
Lead with the answer. Support it after.
No preamble. No throat-clearing. No restating my question. No summary of what you just said. No praise for the question.
Say plainly when something is uncertain, contested, or unknown. Do not paper over a gap.
Match the format to the job: prose for reasoning, bullets for parallel items, tables for comparisons across shared attributes.

RESEARCH AND SOURCING

Ground claims in primary and reputable sources: SEC filings, official company and institution sites, peer-reviewed work, government data, FDA labels, clinical trial registries.
Name the source when it carries the claim.
Search when the answer could have changed since your training data. Anything current — a role, a price, a policy, a version, a status — gets checked, not recalled.
Say which claims are well established and which are thin, preliminary, or disputed.
Do not treat a news aggregator, a forum, or a wiki as a source when a primary one exists.

CODE

Python by default. TypeScript only as a frontend fallback. Python 3.11+, standard library first; justify any dependency.
One function does one task. If the docstring's action line needs the word "and," split the function.
Many small composed functions over few large ones.
Full type hints on every parameter and every return, including private helpers.
Separate pure logic from I/O. A function that reads or writes does not compute. A function that computes does not read or write.
No hidden global state. Data comes in through parameters and leaves through returns.
Guard clauses over nesting. Return early.
Handle the empty case explicitly in anything that divides, averages, indexes, or unpacks.
Do not shadow builtins: dir, id, list, type, input, file.
Catch specific exceptions. A bare except that prints one line and exits hides real bugs.
Return the complete file, not fragments, unless I ask for a diff.
No commented-out code. No TODO stubs.
No AI attribution anywhere: not in code, comments, docstrings, file headers, or commit messages. Hard rule, no exceptions.

DOCSTRING FORMAT

Every function gets exactly three lines, in this order:
  line 1 = what it takes (the inputs and what they mean)
  line 2 = what it does (the action)
  line 3 = what it gives (the output, including edge cases)
One sentence per line. Three lines. No fourth line.
No Args/Returns/Raises blocks. No Google, NumPy, or reStructuredText style.
Applies to every function without exception, including helpers, workers, entry points, and tests.
If raising is part of the contract, fold it into line 3.

def clean_word(word: str) -> str:
    """
    Takes a single word as a string.
    Strips surrounding punctuation and lowercases the rest.
    Gives the cleaned word, empty if nothing remains.
    """

def different_to_total(word_counts: Counter[str], total_words: int) -> float:
    """
    Takes a word frequency counter and the total word count.
    Divides distinct words by total words.
    Gives the ratio as a float, 0.0 when there are no words.
    """

def read_corpus_file(path: Path) -> str:
    """
    Takes a path to a UTF-8 text file.
    Reads the file without interpreting its contents.
    Gives the raw text, or raises UnicodeDecodeError on bad encoding.
    """

</my_rules_verbatim>

**Also required:**
* Claude and Anthropic must never appear anywhere in the repo: not as a contributor, not in commit trailers, not in any text or code.
* On my coding projects, work end to end within each phase: write, test, fix, commit, and push to main. Keep debugging until tests pass. The phase gates in Section 10 still apply.

---

## Appendix E: My example code, word for word, with audit

<my_example_code_verbatim>

```python
# Think about how can i make this code more efficient? - JSON serialization of signatures, caching results, parallel processing for multiple files, etc.

from pathlib import Path
from typing import Optional
import re
import string
import sys
import os

weights = {
    "average_word_length": 11,
    "different_to_total": 33,
    "exactly_once_to_total": 50,
    "average_sentence_length": 0.4,
    "average_sentence_complexity": 4
}

def split_string(text: str, delimiters: str) -> list[str]:
    """
    given a string and a set of delimiters 
    return list of substrings 
    split at any delimiter 
    whitespace removed
    """
    parts = re.split(f"[{re.escape(delimiters)}]", text)
    return [p.strip() for p in parts if p.strip()]

def split_into_sentences(text: str) -> list[str]:
    """
    given a text string
    return list of sentences
    split at . ! or ?
    """
    return split_string(text, ".!?")

def split_into_phrases(sentence: str) -> list[str]:
    """
    given a sentence string
    return list of phrases
    split at , ; or :
    """
    return split_string(sentence, ",;:")

def clean_word(word: str) -> str:
    """
    given a string representing a single word, return "cleaned" version 
    punctuation removed 
    converted to lowercase
    """
    return word.strip(string.punctuation).lower()

def get_clean_words(text: str) -> list[str]:
    """
    given a text string, return list of cleaned words 
    punctuation removed 
    converted to lowercase
    """
    words = text.split()
    return [clean_word(w) for w in words if clean_word(w)]

def average_word_length(text: str) -> float:
    """
    returns the average length of the words in the text
    """
    clean_words = get_clean_words(text)
    if not clean_words:
        return 0.0
    total_length = sum(len(word) for word in clean_words)
    return total_length / len(clean_words)

def different_to_total(text: str) -> float:
    """
    given a text string 
    return ratio of different words to total words
    """
    clean_words = get_clean_words(text)
    total_words = len(clean_words)
    if total_words == 0:
        return 0.0
    different_words = len(set(clean_words))
    return different_words / total_words

def exactly_once_to_total(text: str) -> float:
    """
    returns the ratio of words that occur exactly once to the total number of words
    """
    clean_words = get_clean_words(text)
    total_words = len(clean_words)
    if total_words == 0:
        return 0.0
    word_counts = {}
    for word in clean_words:
        word_counts[word] = word_counts.get(word, 0) + 1
    exactly_once = sum(1 for count in word_counts.values() if count == 1)
    return exactly_once / total_words

def average_sentence_length(text: str) -> float:
    """
    returns the average length of sentences in the text
    """
    sentences = split_into_sentences(text)
    if not sentences:
        return 0.0
    total_words = 0.0
    for sentence in sentences:
        words = sentence.split()
        total_words += len(words)
    return total_words / len(sentences)

def average_sentence_complexity(text: str) -> float:
    """
    given a text string 
    return average number of phrases per sentence
    """
    sentences = split_into_sentences(text)
    if not sentences:
        return 0.0
    total_phrases = sum(len(split_into_phrases(sentence))
                        for sentence in sentences)
    return total_phrases / len(sentences)

def make_signature(text: str) -> dict[str, float]:
    """
    calculate a signature for the text consisting of:
    average_word_length 
    different_to_total 
    exactly_once_to_total 
    average_sentence_length 
    average_sentence_complexity    
    """

    return {
        "average_word_length": average_word_length(text),
        "different_to_total": different_to_total(text),
        "exactly_once_to_total": exactly_once_to_total(text),
        "average_sentence_length": average_sentence_length(text),
        "average_sentence_complexity": average_sentence_complexity(text),
    }

def calculate_distance(sig1: dict[str, float], sig2: dict[str, float]) -> float:
    """
    given two text signatures 
    return weighted distance between them
    """
    total = 0.0
    for feature, weight in weights.items():
        total += abs(sig1[feature] - sig2[feature]) * weight
    return total

def make_known_signatures(labeled_texts_dir: Path) -> dict[str, dict[str, float]]:
    """
    given a directory of labeled texts 
    return dictionary mapping author name to signature
    """
    known_signatures = {}
    for text_file in labeled_texts_dir.glob("*.txt"):
        author = text_file.stem
        with open(text_file, "r", encoding="utf-8") as f:
            text = f.read()
        known_signatures[author] = make_signature(text)
    return known_signatures

def find_closest_signature(unknown_sig: dict[str, float], known_sigs: dict[str, dict[str, float]]) -> Optional[str]:
    """
    given an unknown signature and dictionary of known signatures 
    return name of author with smallest distance
    """
    closest_author = None
    smallest_distance = float("inf")
    for author, known_sig in known_sigs.items():
        distance = calculate_distance(unknown_sig, known_sig)
        if distance < smallest_distance:
            smallest_distance = distance
            closest_author = author
    return closest_author

def guess_author(unlabeled_text_file: Path, labeled_texts_dir: Path):
    """
    given a file of unknown authorship and directory of labeled texts 
    return name of author whose signature is closest to the unknown text
    """
    with open(unlabeled_text_file, "r", encoding="utf-8") as f:
        unknown_text = f.read()

    unknown_sig = make_signature(unknown_text)
    known_sigs = make_known_signatures(labeled_texts_dir)
    return find_closest_signature(unknown_sig, known_sigs)

def choose_file(dir: Path) -> Path:
    """
    dir is a Path to a directory
    returns a Path to a file chosen by the user.
    """
    # get a list of the files in the directory
    texts = sorted(list(dir.iterdir()))
    # print a list of choices
    for i, file in enumerate(texts, start=1):
        print(f"{i}. {file.name}")
    # loop until we get an acceptable answer
    while True:
        try:
            choice = int(
                input(f"Please choose a text by number (1-{len(texts)}): "))
            if choice > 0:
                return texts[choice - 1]
        except (ValueError, IndexError):
            # something went wrong, try again
            pass

def main(labeled_texts_dir: Path, unlabeled_texts_dir: Path):
    """
    labeled_texts_dir is a Path to a directory of labeled texts
    unlabeled_texts_dir is a Path to a directory of unlabeled texts
    guesses the author of a text chosen by the user from the unlabeled directory.
    """
    try:
        text = choose_file(unlabeled_texts_dir)
        author = guess_author(text, labeled_texts_dir)
        print("=" * 60)
        print(f"RESULT: {text.name} was written by {author}")
        print("=" * 60)
    except FileNotFoundError as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)

if __name__ == "__main__":
    # check for required arguments and mode
    if len(sys.argv) < 2:
        print(f"Usage: {sys.argv[0]} texts_directory [--test-all | --print-signatures]", file=sys.stderr)
        print(f"  Default: Interactive mode (choose unknown file)", file=sys.stderr)
        print(f"  --test-all: Test all unknown files automatically", file=sys.stderr)
        print(f"  --print-signatures: Print all signatures and save to JSON", file=sys.stderr)
        sys.exit(2)
    
    texts_dir = Path(sys.argv[1])
    labeled_dir = texts_dir / "labeled"
    unlabeled_dir = texts_dir / "unlabeled"
    
    # Check for optional mode flag
    mode = sys.argv[2] if len(sys.argv) > 2 else None
    
    if mode == "--test-all":
        test_all_unknowns(labeled_dir, unlabeled_dir)
    elif mode == "--print-signatures":
        print_all_signatures(labeled_dir, unlabeled_dir)
    else:
        # Default: interactive mode
        main(labeled_dir, unlabeled_dir)
```

</my_example_code_verbatim>

**Audit of this example.** It shows the granularity I want: small helpers composed into bigger jobs. It is not fully up to my current standards. Copy the good parts, and never reproduce the defects.

**Copy these patterns:**
* Small single-purpose helpers, such as `split_string`, `split_into_sentences`, `split_into_phrases`, and `clean_word`.
* Composition: `make_signature` builds one result from several small feature functions.
* A guard clause that returns `0.0` on empty input before any division.
* `pathlib.Path` for file paths, and type hints on most parameters.

**Do not copy these defects** (each was checked against the code):
1. **Docstring format.** These docstrings use an older "given ... return ..." style, some with four or five lines. Every function must use the three-line Takes / Does / Gives format in Appendix D.
2. **Hidden global state.** `calculate_distance` reads the module-level dict `weights`. Constants go in `UPPER_SNAKE_CASE` and are passed in as parameters.
3. **Builtin shadowing.** `choose_file(dir: Path)` shadows `dir`.
4. **Broad exception.** `main` catches `Exception`. Catch specific exceptions only.
5. **I/O mixed with logic.**
   * `make_known_signatures` and `guess_author` read files and compute in the same function.
   * `choose_file` prints, reads input, and parses in one function.
   * `main` prints and computes.
6. **Undefined functions.** The `__main__` block calls `test_all_unknowns` and `print_all_signatures`, which are not defined. Those modes crash with `NameError`.
7. **Unused import.** `os` is imported and never used.
8. **Missing return type.** `guess_author` and `main` have no return annotation.
9. **Repeated work.**
   * `make_signature` calls three feature functions that each re-run `get_clean_words` on the same text.
   * `get_clean_words` calls `clean_word` twice per word.
   * `guess_author` rebuilds every known signature on every call.
   * Compute once and pass the result in. Cache results as JSON, as the note at the top of the file asks.
10. **Old-style optional.** Use `str | None`, not `Optional[str]`, on Python 3.11+.
11. **Inconsistent counting.** `average_sentence_length` counts raw `split()` tokens, while the other features count cleaned words. Pick one definition and document it.
12. **Float accumulator.** `total_words = 0.0` sums integer counts. Use an integer.
13. **Comments restate the code.** Comments such as "# get a list of the files in the directory" add nothing. Only comment a non-obvious reason.

The note at the top of the file (JSON serialization, caching, parallel processing) is a standing request. Section 6, item 10 applies it to this project.

---
