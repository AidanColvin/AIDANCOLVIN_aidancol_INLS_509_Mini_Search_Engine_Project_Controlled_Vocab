# BUILD PROMPT (UNATTENDED): Drug Interaction Screen, front-end redesign and backend fixes

Owner: Aidan Colvin
Prompt version: 2026-09-22
Repo: https://github.com/AidanColvin/AIDANCOLVIN_aidancol_INLS_509_Mini_Search_Engine_Project_Controlled_Vocab
Live site: https://rx-label-search-aidancolvins-projects.vercel.app/
Work branch: `build/frontend-redesign`

**THIS IS AN UNATTENDED RUN. Nobody is reading the chat. Never ask a
question and wait for an answer. Never stop for approval. Run every
phase in order, end to end, until the definition of done in Section 13
is met or a hard blocker in Section 0.3 stops you. Write everything a
human would need to know into the report files in Section 11.**

---

## 0. How to use this prompt

### 0.1 Reading order

1. This prompt is the contract for all work on this project. Read every
   section and appendix before you write anything.
2. The appendices are verbatim copies of my source material: goals,
   standing rules, and a real API payload. Where the body paraphrases
   an appendix and the two differ, the appendix wins.
3. When rules conflict, follow this order:
   1. Accuracy and safety rules (Section 5).
   2. My coding and style rules (Section 8 and Appendix D).
   3. Scope and functional requirements (Sections 1–7).
   4. Repo rules (Section 9).
   5. Your own defaults. Your defaults always lose.
4. Never invent a field name, URL, API, library, function, number,
   citation, or fact.
5. Do not narrow the scope. Do not add features I didn't ask for. If
   something seems missing, record it under "Open questions" and keep
   going. Do not build it.
6. If something I ask for is a bad idea, record why in the phase
   report, then build the safest version that still meets the
   requirement.

### 0.2 Unattended rules

1. **No questions.** When something is ambiguous, pick the safest
   option under Section 5, record the choice and alternatives in
   `reports/OPEN_QUESTIONS.md`, and keep going.
2. **No approval gates.** Phase 0 writes its audit to a file and
   continues into Phase 1 immediately.
3. **Commit small, commit often.** Commit after every completed module
   with passing tests, and push the work branch after every commit. If
   a usage limit cuts the session off, nothing finished should be lost.
4. **Verify before you assert.** Anything marked "verify" gets checked
   against the repo's code or current official documentation before
   you code against it. Record what you checked, the file or URL, and
   the date in `reports/VERIFIED_FACTS.md`. If a fact can't be
   verified, don't use it: record it in `reports/OPEN_QUESTIONS.md`
   and use the safest fallback.
5. **A failing test is never hidden.** After five distinct fix
   attempts, mark it skipped with a reason string naming the report
   entry, record the failure with the full trace in
   `reports/BLOCKERS.md`, and move on. Never delete a failing test,
   never weaken an assertion to make it pass.
6. **Domain judgment calls are mine.** Where a test needs an expected
   value that requires judgment I haven't given you, build the harness
   against a clearly fake placeholder that proves it runs. You never
   invent the real expected value.
7. **Deploy is allowed only through CI on `main`.** Vercel deploys
   through `.github/workflows/rebuild.yml` on push to `main`. You don't
   deploy by hand. If the merge to `main` is blocked, write
   `reports/MERGE_READY.md` with the exact commands I run, and stop.

### 0.3 Hard blockers (the only reasons to stop early)

Stop, write `reports/BLOCKERS.md` with what happened and the exact next
step for me, and end the session if:

* An external data source or package registry can't be reached after
  three attempts spaced at least two minutes apart.
* `git push` to the work branch fails after three attempts. Before
  stopping, make sure every commit exists locally and write the
  recovery commands.
* A safety or accuracy rule in Section 5 can't be met for a feature.
  Skip that feature, record it, and continue if the rest of the phase
  stands without it. Stop only if the whole phase depends on it.

Everything else is not a blocker. Record it and continue.

---

## 1. Mission

Drug Interaction Screen is a free, open-source web tool. A physician
types a patient's medications and sees what the FDA drug labels say
about taking them together. Every alert shows the label sentence behind
it and links to the full label on DailyMed. The Python backend (search,
tagging, interaction checker) is built and live. The front end is a
plain page that does not feel Apple-made and is not intuitive.

This run does three things, in this order:

1. Fix the backend bugs that stop real medication lists from reaching
   the checker or that produce wrong alerts (Section 7).
2. Rebuild the public front end from the approved design (Sections 3,
   4, and 6) in TypeScript, connected to the existing API.
3. Ship it to the live site and prove it works there.

**Users:** physicians (for example, a hospitalist checking an inpatient
medication list) and anyone else checking a list. Assume no training
and no instructions.

**The central test:** someone opens the site and the cursor is already
in the medication box. They type drugs, press Return, and alerts appear
with no other clicks. Every click or keystroke you add loses users.

**Out of scope:** autocomplete, accounts, saving lists, new data
sources, new vocabulary terms, severity ratings, changes to the tier
rules, and changes to the Part 1 collection scope.

---

## 2. What exists (verify in Phase 0; the code wins over this section)

* **Backend:** the Python package `src/rx_label_search/`. `api/check.py`
  and `api/search.py` are stateless Vercel Python functions that call
  it. `public/index.html` is the current page; you replace it.
* **Deploy:** `.github/workflows/rebuild.yml` runs the build pipeline
  and deploys to Vercel on push to `main` and on a weekly schedule.
  Only `public/` is served as static files (see
  `reports/phase7_serve.md`).
* **Tests:** pytest, 405+ tests. `tests/test_style.py` enforces my
  Python style on `src/`, `tests/`, and `api/`.
* **Known bugs:** `results/report.md`, a live QA run on 10 synthetic
  patients. 49 of 60 entries never resolved to a label, so zero alerts
  fired. Section 7 lists these and the other bugs to fix.
* **Vocabulary:** `MiniVocab_Aidan_Colvin_aidancol.md`. PDLA
  (Prescription Drug Label Attributes), 17 terms, T01–T17. Section 1
  has names, property groups, and hierarchy.

### 2.1 API contract as of 2026-09-22 (verify against `interactions/report.py` and `serve/`)

A trimmed real response is in Appendix B.

**`POST /api/check`**, body `{"medications": "<text>", "use_rxnorm": true}`.
The response has `build_date`, `medication_table`, `alerts`,
`unresolved_entries`, `no_warning_text`, and `notice`.

* **Medication table row:**
  * `as_entered`.
  * `matched_name`: a list, or null when unresolved.
  * `generic`, `base_ingredients`, `brand`, `route`: lists.
  * `fda_class`: a string, "Not listed on label." when absent.
  * `dea_schedule`: "II", "III", "IV", "V", or null.
  * `daily_total` and `daily_total_unit`.
  * `pdla_tags`: a list of `{term_id, name}`.
* **Alert:**
  * `kind`: "group", "pair", or "duplication".
  * `risk`: T14/T15/T16 for groups, T17 for pairs, "shared_ingredient"
    or "active_metabolite" for duplication.
  * `title`.
  * `tier`: 1–4, or null for duplication.
  * `tier_name`.
  * `members`: a list of `{drug_name, set_id, effective_time, section,
    sentence, dailymed_url}`.
  * `note`.
* **Tiers** come from the label section, not from clinical severity:

  | Tier | Name | Label section |
  | :--- | :--- | :--- |
  | 1 | Contraindicated | contraindications |
  | 2 | Boxed warning | boxed_warning |
  | 3 | Warning | warnings_and_cautions, warnings, precautions |
  | 4 | Interaction note | drug_interactions |

* **Unresolved entry:**
  * `raw_text`.
  * `status`: "unresolved" or "needs_confirmation".
  * `reason`.
  * `candidates`: strings shaped "NAME → INGREDIENT SET".
* **Missing build data:** HTTP 503 with
  `{"error": "checker data not built yet: ..."}`.

**`GET /api/search?q=...&term=T14&term=T15&operator=AND&limit=20`**
returns `hits`, `query`, `operator`, and `build_date`.

* **Hit fields:** `set_id`, `brand_name`, `generic_name`, `snippet`,
  `tags`, `effective_time`, `score`.
* **Limit:** at most 50.
* **Empty `q` with terms:** runs a filter-only search.

**`GET /api/search?terms_only=1`** returns `build_date` and
`available_terms`, a list of `{term_id, name, property_group}`.

---

## 3. Design

### 3.1 Reference images

Six images of the approved design. Look for them in
`design/2026-09-22-redesign/images/` or attached to this chat. If you
find them in neither place, Sections 3–6 are the full spec.

| File | Shows |
| :--- | :--- |
| `01-interactions-first-visit.png` | First visit: title and an auto-focused medication field |
| `02-interactions-results.png` | Results on desktop: list, inline match choice, alert cards |
| `03-interactions-phone-dark.png` | The same results at 390px wide, dark mode |
| `04-label-search.png` | Label search with grouped vocabulary filters |
| `05-alert-cards-by-tier.png` | The card for each tier, plus duplicate therapy |
| `06-no-warning-and-error.png` | The no-warning result and the error state |

The drug data in the images is real checker output on the fixture
labels. The live page renders real API data. Bracketed text in image
05 marks placeholders. The images use a stand-in font because SF Pro
isn't available where they were made; the page itself uses the system
font stack below.

### 3.2 Tokens

* **Font:**
  * Stack: `-apple-system, BlinkMacSystemFont, system-ui, "Helvetica Neue", "Segoe UI", Roboto, Arial, sans-serif`.
  * Do not self-host SF Pro; Apple's license limits it to Apple
    platforms.
  * `font-variant-numeric: tabular-nums` for doses, counts, and dates.
* **Sizes:**
  * Page title: 34px/1.15 bold, letter-spacing -0.02em.
  * Alert count: 28px bold.
  * Card title: 19px semibold.
  * Row name: 17px.
  * Secondary text: 15px.
  * Captions: 13px minimum.
* **Light mode:**
  * Page #F5F5F7, surface #FFFFFF.
  * Text #1D1D1F, secondary text #6E6E73.
  * Hairline #E5E5EA, border #D2D2D7, field border #86868B.
  * Accent #1F6FA8 (hover #175A8A), accent tint #EAF2F9.
* **Dark mode** (`prefers-color-scheme: dark`):
  * Page #000000, surface #1C1C1E, raised #2C2C2E.
  * Text #F5F5F7, secondary #A1A1A6, hairline #38383A.
  * Accent text #4B9CD3. Buttons keep a #1F6FA8 fill with white text.
* **Tier colors:**
  * Contraindicated: #B42318 (dark #FF7A6B).
  * Boxed warning: #1D1D1F, drawn as a 2px solid box around the whole
    card with radius 4. The box echoes the boxed warning on the FDA
    label. In dark mode the box is #F5F5F7.
  * Warning: #9A5A0F (dark #E0A04A).
  * Interaction note and Duplicate therapy: #3A3A3C (dark #D1D1D6).
* **Radius:** 12 for cards and lists, 14 for text fields, 4 for the
  boxed-warning card. Buttons and pills are fully round.
* **Shadows:** None on cards.
* **Header:**
  * Translucent background with
    `backdrop-filter: saturate(180%) blur(20px)`, plus the `-webkit-`
    version.
  * Hairline bottom border.
* **Targets and contrast:**
  * Tap targets at least 44px.
  * Text contrast at least 4.5:1, UI boundaries at least 3:1.
  * Measure every pair and list the ratios in the report.
* **Motion:**
  * Only in answer to an action, 200–250ms ease-out.
  * None under `prefers-reduced-motion`.

### 3.3 Header (every view)

* **Height:** 52px, full width.
* **Home button:** The logo (`public/brand/logo.svg`) sits in the
  top-left corner as a 44px link, 12px in. It opens the Interactions
  view and never clears the list.
* **Name and views:** "Drug Interaction Screen" sits at the left of a
  centered 1040px container. The segmented control
  "Interactions | Label search" is centered.
* **Phone:** The logo and name share the top bar. The segmented control
  runs full width below it.
* **URL:** The hash holds the view only (`#search` for Label search).

---

## 4. Interactions view

### 4.1 Layout (720px column; see images 01–03)

* **Title:** "Check drug to drug interactions".
* **Medication field:**
  * 56px tall, radius 14.
  * Focused on page load (`autofocus` plus a `focus()` call), so no
    click is needed.
  * Placeholder "Add a medication", then "Add another medication" once
    the list has entries.
  * A round + button sits inside the right edge.
* **Hint:** "Press Return to add. Paste a list to add many at once." It
  shows under the field only while the list is empty.
* **List header:** "{n} medications" and a "Clear all" button, above
  the list.
* **Each resolved row:**
  * Line 1: the generic name in lowercase, semibold.
  * Line 2: the text as entered, in secondary color.
  * "Spelling corrected" tag when the typed name (the first item in
    `matched_name`) matches none of the row's brand, generic, or
    base-ingredient names, ignoring case.
  * Right side: daily total ("40 mg/day", no trailing ".0"), then a
    DEA badge "C-II" when `dea_schedule` is set, then a chevron.
  * Tapping the row expands it in place to show FDA class, route, base
    ingredients, the matched chain joined with " → ", and label terms
    by name.
  * Remove (×) shows on hover and keyboard focus. On touch screens it
    always shows (`@media (hover: none)`).
* **Unresolved rows with candidates:**
  * They stay in place and show "Which one?" in accent.
  * Below that, one pill button per candidate, labeled with the part
    before " → ", lowercased.
  * Choosing one replaces the name in that row and re-runs the check.
  * If the result still needs confirmation, show the choices again.
* **Unresolved rows without candidates:** Show
  "Not found. Tap to edit." Tapping turns the row back into an
  editable field.

### 4.2 Results

Results show below the list whenever the list has at least one entry.

* **Heading:**
  * "{n} alerts" at 28px, singular for 1.
  * With no alerts, the heading is `data.no_warning_text` instead.
* **Checked count:** "{resolved} of {total} medications checked", where
  resolved means rows with a non-null `matched_name`.
* **Notice:** `data.notice` in 13px secondary text, directly under the
  count. It shows whenever results show.
* **Card order:** Sort cards by tier from 1 to 4, with duplication
  last. Keep API order within a tier.
* **Each card:**
  * Tier line: an icon plus `tier_name`, word for word. For
    `kind: "duplication"`, show "Duplicate therapy".
  * Title: `alert.title`.
  * Drugs: the members' `drug_name` values, joined with ", ".
  * One label sentence in a gray quote block. Use the member from the
    strongest section, in this order: contraindications, boxed_warning,
    warnings_and_cautions/warnings/precautions, drug_interactions.
  * Under the quote: "{drug}, {Section} section" and a "DailyMed" link.
    The link opens a new tab, and its aria-label names the drug.
  * "Show {n} more label sentences" expands the rest in the same
    format.
  * Pair alerts show only the first member's sentence (the source
    label). Never show the second member's sentence as that drug's own
    label text.
  * Skip any member whose `section` is empty. It has no label sentence.
* **Section names:**

  | API value | Shown as |
  | :--- | :--- |
  | `contraindications` | Contraindications |
  | `boxed_warning` | Boxed Warning |
  | `warnings_and_cautions` | Warnings and Precautions |
  | `warnings` | Warnings |
  | `precautions` | Precautions |
  | `drug_interactions` | Drug Interactions |
  | `description` | Description |

* **Icons:** Inline stroke SVGs:
  * Tier 1: circle with a slash.
  * Tier 2: square.
  * Tier 3: triangle.
  * Tier 4: two linked circles.
  * Duplicate therapy: two overlapping squares.

### 4.3 Behavior

* **Adding:**
  * Return adds the entry.
  * Pasting text with commas, semicolons, or new lines adds one row per
    entry.
* **Running the check:**
  * There is no Check button. Every change to the list runs
    `/api/check`.
  * Debounce by 300ms, and cancel the older request with
    `AbortController`.
  * Send the rows joined with `\n`, with `use_rxnorm: true`.
* **While loading:**
  * Keep the old results on screen, dimmed, with a small spinner by the
    count.
  * Never blank the page.
* **Announcement:** Announce "{n} alerts" through an
  `aria-live="polite"` region.
* **Focus:**
  * Focus stays in the field after adding.
  * It returns to the field after the user chooses a candidate or
    removes a row.
* **Clear all:** Empties the list and the results.
* **Errors:**
  * Handle a network failure, a non-2xx response, and bad JSON
    separately.
  * Show one card: a one-line message, the API's `error` text in small
    type, and a "Try again" button.
  * For the 503: "Checker data isn't ready yet."
* **Length limit:**
  * If the joined text passes 4,000 characters, don't send it.
  * Show: "The list is too long. Remove some medications and try
    again."

---

## 5. Accuracy and safety rules

1. **Required text:** Render `data.notice` and `data.no_warning_text`
   word for word. Never shorten, hide, or make them dismissible.
2. **Banned wording:**
   * Never write "safe," "no interactions," "all clear," "severity," or
     "major/moderate/minor," and never show a green check.
   * Tiers say which label section the evidence came from, not how
     dangerous a combination is.
   * Tier 4 gets full text weight. Never fade it.
3. **Honest evidence:**
   * Never show a sentence as coming from a label it did not come from.
   * Pair alerts show the source label's sentence only.
4. **No silent loss:** Never drop a medication without telling the user.
   That covers the 4,000-character limit, unresolved rows, and failed
   requests.
5. **Safe rendering:**
   * Never put API or user text into `innerHTML`. Build nodes with
     `createElement` and `textContent`.
   * Use a DailyMed URL as an `href` only if it starts with
     `https://dailymed.nlm.nih.gov/`.
   * External links get `rel="noopener noreferrer"`.
6. **No stored data:** Never store the medication list: no
   localStorage, sessionStorage, cookies, or URL. Clinicians may enter
   real patient lists on shared workstations.
7. **Unchanged rules:** Do not change any tier rule, tag rule, or the
   notice text.

---

## 6. Label search view (see image 04)

* **Title:** "Search labels".
* **Search field:**
  * Same style as the medication field, focused on load.
  * Placeholder "Search label text", plus a clear button.
* **When searches run:**
  * Search as the user types (debounce 250ms) and on every filter
    change.
  * Empty text with filters runs a filter-only search.
  * Empty text with no filters shows nothing.
  * Use `limit=20`, and show "Showing the top 20" when 20 come back.
* **Filters:**
  * A 280px sidebar beside the results on wide screens.
  * Under 768px, a "Filters" button opens them in a bottom sheet
    (`<dialog>`).
  * Group by `property_group` from `/api/search?terms_only=1`, ordered
    by first appearance.
  * Indent narrower terms: T10 under T07, T06 and T12 under T11, and
    T14–T17 under T13. The API does not return this hierarchy, so keep
    it in one constant with a comment citing MiniVocab Section 1.
  * Each filter is a full-width row button (`aria-pressed`) showing the
    term name, then its ID in small secondary text.
  * Selected rows get the accent tint and a checkmark.
  * "Clear" appears when any filter is on.
  * "Match all | Match any" (AND | OR) appears when two or more are on.
* **Results:**
  * "{n} results", then the rows in one white list.
  * Title: the brand name. If it is empty or matches the generic name
    (ignoring case), show the generic name in lowercase instead. When
    the brand shows, the generic follows in secondary text.
  * Snippet: the query's words in bold. Split the text into nodes; no
    `innerHTML`.
  * Tags that match the active filters show as accent pills, then
    "+{n} more", which expands the rest by name.
  * A "DailyMed" link built from `set_id` with the template in
    `interactions/evidence.py`.
* **Empty state:** "No labels match. Try fewer filters or Match any."

---

## 7. Backend fixes

Each fix is its own commit with tests on the committed fixtures. All
existing tests keep passing.

1. **Parser** (Bugs 1 and 2 in `results/report.md`):
   * Accept "1 time daily" (singular).
   * Strip trailing directions such as "as needed", "PRN", and
     "at bedtime" before name matching.
   * Add every failing example from the report as a test with
     `use_rxnorm` off.
   * Stop dose text from leaking into the RxNorm query. The report
     shows "Lisinopril 1 time → lisinopril 1 MG/ML".
2. **Silent truncation:**
   * `serve/api_check.py` cuts the text at 4,000 characters, so
     medications past the cut are never checked and no one is told.
   * Return HTTP 413 with `{"error": "..."}` instead.
3. **False Contraindicated alerts** in `interactions/pairs.py`:
   * `sentence_mentions_drug` uses a plain substring match, so
     "venlafaxine" matches inside "desvenlafaxine". Match on word
     boundaries.
   * It also matches drug names in the hypersensitivity clause of a
     contraindications sentence. Only match clauses about taking drugs
     together.
   * Test: the venlafaxine and desvenlafaxine fixtures must give no
     pair alert from either cause.
4. **Copied evidence:**
   * Pair alerts copy the source drug's sentence onto the other drug,
     with the other drug's DailyMed link.
   * Give the other member an empty `sentence` and `section` instead.
5. **Duplication alerts:**
   * They come back with `tier: null` and `tier_name: "heuristic"`. Set
     `tier_name` to "Duplicate therapy".
   * Each member's `drug_name`, `set_id`, and `sentence` must come from
     the same label.
   * Give a "base ingredients: ..." member an empty `section` so the
     front end skips it.
6. **Evidence choice for T14, T15, and T16:**
   * Keep the sentence that names combined use, such as
     "concomitant use" or "other CNS depressants".
   * Test: the OxyContin fixture's T15 evidence must be the
     boxed-warning sentence about concomitant use with benzodiazepines
     or other CNS depressants, not the general respiratory-depression
     line.
   * Change only which sentence is kept, not which labels get the term.
7. **Heading noise:**
   * Strip leading section headings and reference marks from evidence
     sentences, such as "5 WARNINGS AND PRECAUTIONS", "WARNINGS",
     "7 DRUG INTERACTIONS", and "( 5.4 ) •".
   * Leave the rest of the sentence unchanged.
   * Test with the trazodone, venlafaxine, OxyContin, and Lyrica
     fixtures.

---

## 8. Coding standards

### 8.1 Python (backend)

Follow the existing code and `tests/test_style.py`. My rules, word for
word:

```
Python by default. TypeScript only as a frontend fallback. Python 3.11+, standard library first; justify any dependency.
One function does one task. If the docstring's action line needs the word "and," split the function.
Many small composed functions over few large ones.
Full type hints on every parameter and every return, including private helpers.
Separate pure logic from I/O. A function that reads or writes does not compute. A function that computes does not read or write.
No hidden global state. Data comes in through parameters and leaves through returns.
Guard clauses over nesting. Return early.
Handle the empty case explicitly in anything that divides, averages, indexes, or unpacks.
Do not shadow builtins: dir, id, list, type, input, file.
Catch specific exceptions. A bare except that prints one line and exits hides real bugs.
Return the complete file, not fragments, unless I ask for a diff.
No commented-out code. No TODO stubs.
No AI attribution anywhere: not in code, comments, docstrings, file headers, or commit messages. Hard rule, no exceptions.

Every function gets exactly three lines, in this order:
  line 1 = what it takes (the inputs and what they mean)
  line 2 = what it does (the action)
  line 3 = what it gives (the output, including edge cases)
One sentence per line. Three lines. No fourth line.
No Args/Returns/Raises blocks. No Google, NumPy, or reStructuredText style.
Applies to every function without exception, including helpers, workers, entry points, and tests.
If raising is part of the contract, fold it into line 3.
```

### 8.2 TypeScript (front end)

The front end is TypeScript in `web/`, compiled by `tsc` to ES modules
in `public/js/`, which is gitignored and built in CI. There is no
bundler and no runtime dependency.

1. **Dependencies:**
   * `typescript` is the only dependency, and it is a dev dependency.
     Pin the current stable version (verify on the npm registry).
   * Tests use Node's built-in `node:test` and `node:assert` on the
     compiled output, so there is no test-runner package.
   * Enforce style with the TypeScript compiler API in a test (item 15),
     not ESLint.
   * Record this choice and its reason in `reports/OPEN_QUESTIONS.md`.
   * Any other dependency needs a one-line justification there too.
2. **`tsconfig.json`:** `"strict": true`, `useUnknownInCatchVariables`,
   `noUnusedLocals`, `noUnusedParameters`, `noImplicitReturns`,
   `lib: ["ES2022", "DOM", "DOM.Iterable"]`, and ES module output.
   Relative imports end in `.js` so browsers can load them (verify).
3. **One function does one thing.** If the comment's "does" line needs
   the word "and," split the function. Many small composed functions
   over few large ones.
4. **Every function gets a three-line JSDoc comment, in this order:**
   ```
   /**
    * Takes <the inputs and what they mean>.
    * <The one action this function does>.
    * Gives <what comes back, including edge cases>.
    */
   ```
   One sentence per line. Three lines. No `@param`, `@returns`, or
   `@throws` tags. Plain English. This applies to every function without
   exception: helpers, entry points, and tests. A function with no
   arguments says "Takes no arguments." If throwing is part of the
   contract, fold it into line 3.
5. **Full explicit types on every parameter and every return**,
   including private helpers and arrow functions. No `any`; use
   `unknown` and narrow it.
6. **Separate pure logic from I/O:**
   * Pure modules format, sort, match, and decide. They never touch
     `fetch` or the DOM.
   * `api.ts` only fetches.
   * Render modules only build DOM nodes from data they are given.
7. **No hidden module-level state read inside functions.**
   * One app state object is created in `main.ts` and passed down.
   * Constants live at module scope in `UPPER_SNAKE_CASE`.
8. **Don't mutate a caller's data.** Return new objects and arrays
   (spread, `toSorted`, `structuredClone` where needed).
9. **Guard clauses, return early.** Handle the empty case explicitly in
   anything that divides, averages, indexes, or destructures.
10. **Don't shadow globals:** `Array`, `Object`, `Map`, `Set`, `String`,
    `Number`, `Boolean`, `Promise`, `Error`, `JSON`, `Math`, `Date`,
    `RegExp`, `Symbol`, `globalThis`, `window`, `document`, `location`,
    `navigator`, `history`, `event`, `name`, `status`.
11. **Catch specific errors only.**
    * Write `catch (err: unknown)`, then narrow with `instanceof` before
      handling.
    * Never write a bare catch that swallows the error.
    * Validate API responses at the boundary in `api.ts`, and fail
      loudly on bad shapes.
12. **Records are immutable.** Every record type gets `readonly` on
    every field. Build them with factory functions.
13. **Tests: one per pure function**, including the empty case, plus
    regression tests. Build them from the Appendix B payload and from
    real `/api/check` output on the fixture labels. Test functions get
    the three-line JSDoc comment too.
14. **Complete files only.** Return complete files, never fragments. No
    commented-out code. No TODO stubs.
15. **Enforce these rules with tests from the first commit:**
    * `web/tests/style.test.ts` parses every file in `web/src/` and
      `web/tests/` with the TypeScript compiler API. It fails if:
      * a function lacks the three-line Takes / Does / Gives comment;
      * a parameter or return lacks an explicit type;
      * `any` appears;
      * a catch variable isn't typed `unknown`;
      * a parameter shadows a name in item 10.
    * Extend the existing `tests/test_no_attribution.py` to scan `web/`
      and `public/`. Don't add a second attribution test.
16. **Read the style skill.** If a project style skill is available to
    you, read it before writing or refactoring code.

---

## 9. Repo rules and layout

### 9.1 Target repo

AidanColvin/AIDANCOLVIN_aidancol_INLS_509_Mini_Search_Engine_Project_Controlled_Vocab.
Clone it and create the work branch `build/frontend-redesign` from
`main`. All work happens on that branch.

### 9.2 Read-only

These are my write-ups and records. Never edit them:

* `MiniVocab_Aidan_Colvin_aidancol.md`
* `rubrics/`
* `notes/`
* `document_collection_part_1/`
* `LICENSE`
* Every existing file in `results/`
* Every existing report in `reports/`

Add new report files instead. For the three shared logs
(`VERIFIED_FACTS.md`, `OPEN_QUESTIONS.md`, `BLOCKERS.md`), append under a
heading "Redesign run, 2026-09-22". Never rewrite what is there.

### 9.3 Layout added by this run

```
web/
    package.json            typescript as the only dev dependency
    tsconfig.json
    src/
        main.ts             entry: builds app state, wires events
        api.ts              fetch calls and response validation only
        records.ts          readonly record types and factories
        format.ts           pure: names, doses, dates, section names
        alerts.ts           pure: sort, pick evidence, pair and duplication rules
        meds.ts             pure: split pasted text, spelling-corrected check, candidate labels
        search.ts           pure: snippet word split, tag grouping, vocabulary hierarchy
        render_*.ts         DOM building only
    tests/
        style.test.ts
        [one test file per pure module]
public/
    index.html              rewritten
    styles.css              new
    js/                     compiled output, gitignored, built in CI
design/2026-09-22-redesign/images/   the six reference images, if present
```

Keep `package.json` inside `web/` so Vercel's Python detection at the
repo root is unchanged (verify).

### 9.4 Git rules

* **Branch:** Work on the branch only. Never commit directly to `main`
  during the run.
* **Commit messages:** Plain, specific, in the imperative mood, for
  example `Accept singular "1 time daily" in the medication parser`.
  Write the message to a temp file and commit with `git commit -F <file>`
  so no tool adds text to it.
* **Push:** After every commit, run
  `git push -u origin build/frontend-redesign`.
* **History:** Never force-push, never rewrite pushed history, and
  never move or delete tags.
* **What to commit:** Code, reference files, fixtures, and reports.
  Never secrets, raw data, or build output. `public/js/` is build
  output.
* **Attribution scrub, required before every push:**
  1. The repo already has `.githooks/commit-msg`. Verify it. Then run
     `git config core.hooksPath .githooks`, which is a local setting
     only.
  2. Before every push, run
     `git log --format=%B origin/build/frontend-redesign..HEAD`. Check
     it for lines starting `Co-Authored-By:`, lines containing
     `noreply@`, lines starting `Generated with`, and lines matching
     `^[A-Za-z]+-Session: https://`. Also search case-insensitively
     for the two forbidden names. Fix unpushed commits only.
  3. Never create `CLAUDE.md`, `AGENTS.md`, or a `.claude/` directory
     in the repo. Delete one before committing if a tool creates it.
* **CI:** Add a step to `.github/workflows/rebuild.yml`, before
  `vercel build`. It runs `npm ci`, `tsc`, and the web tests in `web/`,
  and it fails the deploy if any of them fail. Verify that Node is on
  the runner and that `vercel build` includes the gitignored
  `public/js/`. Confirm on the live site that `/js/main.js` loads.
* **Final merge:** At the end of the last phase, merge the work branch
  into `main` and push. If blocked, write `reports/MERGE_READY.md` with
  the exact commands, and stop.

### 9.5 Test fixtures

* **Existing fixtures:** Real openFDA labels in `tests/fixtures/labels/`
  and RxNav responses in `tests/fixtures/rxnorm/`, documented in
  `tests/fixtures/FIXTURES.md`.
* **Offline checker:** The acceptance test
  (`tests/test_interactions_acceptance.py`) shows how to run the full
  checker offline on them.
* **New fixtures:** Add one only if you fetch it from the official API.
  Record `fetched_on` and `source_url`, and document it in
  `FIXTURES.md`.

### 9.6 Docs

* **README.md:** Extend it with how to build and test the front end
  (`cd web && npm ci && npx tsc && npm test`). Keep all existing
  content.
* **DATA_SOURCES.md:** Add nothing unless you add a data source. This
  run shouldn't.

---

## 10. Build phases

Run every phase in order, end to end, without stopping. Within a phase:
write, test, fix, commit, push. At the end of each phase, write the
phase report (Section 11) and start the next.

### Phase 0: Audit and plan
* Clone, create the branch, list every file, and record the read-only
  paths.
* Read every source in Section 2.
* Verify the API contract (2.1), how Vercel serves `public/`, what
  `rebuild.yml` runs, the runner's Node version, the current stable
  TypeScript version, and browser support for ES modules and
  `backdrop-filter` in Safari, Chrome, and Firefox. Record each in
  `reports/VERIFIED_FACTS.md`.
* Write `reports/redesign_phase0_audit.md`.
* **Done when:** The audit is written and every "verify" item is either
  recorded or listed in `OPEN_QUESTIONS.md`.

### Phase 1: Parser fixes (7.1)
* **Done when:** Every failing example in `results/report.md` resolves
  in a test with `use_rxnorm` off, and all tests pass.

### Phase 2: API fixes (7.2, 7.4, 7.5)
* **Done when:** Text over 4,000 characters gets a 413 with an error.
  Pair alerts carry no copied sentence. Duplication alerts have correct
  attribution and the "Duplicate therapy" tier name. All tests pass.

### Phase 3: Evidence quality (7.3, 7.6, 7.7)
* **Done when:** The venlafaxine and desvenlafaxine fixtures give no
  false pair alert. OxyContin's T15 evidence is the concomitant-use
  sentence. Heading noise is gone in the named fixtures. Which labels
  get each term is unchanged; prove it by diffing term assignment on
  every fixture before and after. All tests pass.

### Phase 4: Front-end toolchain
* **Done when:** `web/` builds with `tsc`. Style and web tests pass.
  The attribution test covers `web/` and `public/`. The CI step is
  added. A minimal `main.ts` loads from `public/js/` in a local run.

### Phase 5: Interactions view (Sections 3.3, 4, 5)
* **Done when:** Every item in Section 4 works against the local API,
  and every pure function has tests.

### Phase 6: Label search view, dark mode, phone layout (Sections 3, 6)
* **Done when:** Every item in Section 6 works. Dark mode and the 390px
  layout match images 03 and 04. The filter sheet works under 768px.

### Phase 7: Local verification
Run the site locally with the API functions, as
`reports/phase7_serve.md` describes, and check each case:

1. On page load, the cursor is in the medication field with no click.
2. Paste "OxyContin 20 mg bid, Ambien 10 mg qhs, trazdone 50 mg qhs,
   Flexril 10 mg tid, Lyrica 100 mg tid, dextroamphetamine 10 mg bid"
   in one go. Expect six rows, "Spelling corrected" on the misspelled
   names, a "Which one?" row if dextroamphetamine is ambiguous, and
   alerts with no click.
3. Choose a candidate. The row resolves and the alerts update.
4. "losartan 50 mg daily, gabapentin 300 mg tid" shows
   `no_warning_text` as the heading, plus the notice.
5. "venlafaxine 75 mg daily, desvenlafaxine 50 mg daily" shows no
   Contraindicated alert.
6. The examples in `results/report.md` resolve.
7. Text over 4,000 characters shows the length message, and nothing is
   dropped silently.
8. `<img src=x onerror=alert(1)>` shows as plain text, and nothing runs.
9. Keyboard only, start to finish. VoiceOver in Safari.
10. 320px width, dark mode, and reduced motion.

Then screenshot both views in light and dark, on desktop and at 390px,
with results showing. Compare them with the reference images, fix what's
off, and repeat. A dev-only headless browser is fine; don't add it to
`web/package.json`. Commit the final screenshots to
`reports/redesign_screenshots/`.

* **Done when:** All ten cases pass, and the screenshots match the
  images.

### Phase 8: Ship
* Merge to `main` and push. Confirm `rebuild.yml` deploys.
* Re-run the Phase 7 cases on the live site.
* Re-run `results/run_patients.py` (read it first). Write the new
  output to `results/rerun_2026-09-22/` without overwriting anything in
  `results/`.
* Report resolved entries against the earlier 11 of 60, and alerts
  fired against the earlier 0.
* **Done when:** The live site passes every case and the QA re-run is
  reported.

---

## 11. Reports

Write these under `reports/` and commit them with the code:

* **Phase reports:** `reports/redesign_phase0_audit.md` through
  `reports/redesign_phase8_ship.md`. Each covers:
  * What was built (five lines or fewer).
  * Commands run and test results (pass, fail, and skip counts).
  * Commits and push result.
  * Any expected value a real source contradicted, and what the test
    now asserts.
  * What I should check by hand.
  * Open questions.
* **Shared logs:** Append to `reports/VERIFIED_FACTS.md`,
  `reports/OPEN_QUESTIONS.md`, and `reports/BLOCKERS.md` under the
  heading "Redesign run, 2026-09-22".
* **Final report:** `reports/REDESIGN_FINAL_REPORT.md` covers:
  * The state of every phase against Section 13.
  * The contrast-ratio table.
  * The before-and-after QA numbers.
  * How to build and test the front end.
  * The first three things I should do when I return.

Plain English, short sentences. No preamble, no praise, no summary of
what you just said.

---

## 12. End of session

Before the final push:

1. Zip the new `reports/redesign_*` files, `README.md`, the reference
   images, and a copy of this prompt into
   `reports/bundle_2026-09-22_redesign.zip`.
2. Commit and push the zip with the final report.
3. Save the session record and every changed file to my project
   programs folder.

---

## 13. Definition of done

* **Live page:** On the live site, the cursor is in the medication
  field on load. Pasting a list shows alerts with no other clicks.
  Every behavior in Sections 3, 4, and 6 works.
* **Safety rules:** Every rule in Section 5 holds on the live site.
* **Backend fixes:** Every fix in Section 7 is merged with tests. Every
  `results/report.md` example resolves. Venlafaxine plus desvenlafaxine
  gives no false Contraindicated alert.
* **QA re-run:** The re-run is reported against 11 of 60 resolved and 0
  alerts.
* **Tests:** The Python style tests, TypeScript style tests,
  attribution test, and all other tests pass. Every skipped test is
  listed in `reports/BLOCKERS.md`.
* **Attribution:** "Claude" and "Anthropic" appear nowhere in the repo,
  including commit messages.
* **Final report:** `reports/REDESIGN_FINAL_REPORT.md` is committed and
  pushed, and `main` has the merge, or `reports/MERGE_READY.md` says
  how to do it.

---

## Appendix A: My goals, word for word

Message 1:

> I am building a frie open source md drug to drug interaction tool https://rx-label-search-aidancolvins-projects.vercel.app
> https://github.com/AidanColvin/AIDANCOLVIN_aidancol_INLS_509_Mini_Search_Engine_Project_Controlled_Vocab
>
> I feel the front end dose not feel like apple made it it lacks being intative to a md or any person I want it to be pretty and welcoming and intative give me a detailed prompt how u would change th9is website look

Message 2:

> show me how the perfect would be be using ur redesign

Message 3:

> it looked great but where did it go
>
> small adjustments I want it to feel almost like apple health
> clean consise
> no extra elaboration or long meaningless sentences
> everything needs to be easy to use by any one and completely intative
> while this is a tool first page we dont want user to have to click not know where to click what to do right Steve Jobs ellimated this
> think u open a google browser page ur auto in the search bar u dont need to click or find it
> the key is to rember intative to every one
> for every action the user needs to do it will reduce the number of users more clicks or typing the more users will not use
>
> make it easy for the user intative helpful and clear

Design comment on the logo:

> move this to left Conner and make it a button for this home pqge on all pages

Design comment on the page title:

> Say instead --->  Check drug to drug interactions

Message 4:

> this is perfect can u give me a prompt I can give to clauid code to use this and update the front end public website and connecting it to our full program

Message 5:

> my dowlades is messed up can u give me a single file containing both and the images how how it should look that I can paste into a new clauid code chat for this project th9s  is the front end website https://rx-label-search-aidancolvins-projects.vercel.app/
> so one single large md raw and also include the pictures that u made  like u can do that as separate but important to have this is the GitHub repo https://github.com/AidanColvin/AIDANCOLVIN_aidancol_INLS_509_Mini_Search_Engine_Project_Controlled_Vocab

---

## Appendix B: Real `/api/check` response, trimmed

This is from the repo's own checker, run offline on the fixture labels
(build date 2026-09-21), for "OxyContin 20 mg bid, Ambien 10 mg qhs,
trazdone 50 mg qhs, Flexril 10 mg tid, Lyrica 100 mg tid,
dextroamphetamine 10 mg bid". It keeps two table rows, one alert with
two of its five members, and three of the 14 tags. The live
collection may resolve names differently.

```json
{
  "build_date": "2026-09-21",
  "medication_table": [
    {
      "as_entered": "OxyContin 20 mg bid",
      "matched_name": ["OxyContin", "OXYCODONE HYDROCHLORIDE"],
      "generic": ["OXYCODONE HYDROCHLORIDE"],
      "base_ingredients": ["oxycodone"],
      "brand": ["OxyContin"],
      "fda_class": "Not listed on label.",
      "route": ["ORAL"],
      "dea_schedule": "II",
      "daily_total": 40.0,
      "daily_total_unit": "mg",
      "pdla_tags": [
        {"term_id": "T01", "name": "Boxed Warning"},
        {"term_id": "T02", "name": "Oral Route"},
        {"term_id": "T03", "name": "Pediatric Indication"}
      ]
    },
    {
      "as_entered": "dextroamphetamine 10 mg bid",
      "matched_name": null,
      "generic": [],
      "base_ingredients": [],
      "brand": [],
      "fda_class": "Not listed on label.",
      "route": [],
      "dea_schedule": null,
      "daily_total": 20.0,
      "daily_total_unit": "mg",
      "pdla_tags": []
    }
  ],
  "alerts": [
    {
      "kind": "group",
      "risk": "T15",
      "title": "CNS Depression Risk shared by 5 drugs",
      "tier": 2,
      "tier_name": "Boxed warning (heuristic)",
      "members": [
        {
          "drug_name": "OxyContin",
          "set_id": "bfdfe235-d717-4855-a3c8-a13d26dadede",
          "effective_time": "20260624",
          "section": "boxed_warning",
          "sentence": "Life-Threatening Respiratory Depression Serious, life-threatening, or fatal respiratory depression may occur with use of OXYCONTIN, especially during initiation or following a dosage increase .",
          "dailymed_url": "https://dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=bfdfe235-d717-4855-a3c8-a13d26dadede"
        },
        {
          "drug_name": "Ambien",
          "set_id": "c36cadf4-65a4-4466-b409-c82020b42452",
          "effective_time": "20250415",
          "section": "warnings_and_cautions",
          "sentence": "Risk increases with dose and use with other CNS depressants and alcohol.",
          "dailymed_url": "https://dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=c36cadf4-65a4-4466-b409-c82020b42452"
        }
      ],
      "note": ""
    }
  ],
  "unresolved_entries": [
    {
      "raw_text": "dextroamphetamine 10 mg bid",
      "status": "needs_confirmation",
      "reason": "two or more names are equally close",
      "candidates": [
        "DEXTROAMPHETAMINE SACCHARATE → AMPHETAMINE ASPARTATE MONOHYDRATE, AMPHETAMINE SULFATE, DEXTROAMPHETAMINE SACCHARATE, DEXTROAMPHETAMINE SULFATE",
        "DEXTROAMPHETAMINE SULFATE → AMPHETAMINE ASPARTATE MONOHYDRATE, AMPHETAMINE SULFATE, DEXTROAMPHETAMINE SACCHARATE, DEXTROAMPHETAMINE SULFATE | DEXTROAMPHETAMINE SULFATE"
      ]
    }
  ],
  "no_warning_text": "No warning found in the labels checked.",
  "notice": "Results reflect FDA label text as of 2026-09-21. \"No warning found\" does not mean a combination is safe. This tool is not validated for clinical use and does not replace clinical judgment or a licensed drug interaction database."
}
```

Two things in this payload are bugs that Section 7 fixes:

* **Wrong evidence sentence:** The OxyContin sentence is the general
  respiratory-depression line, not the concomitant-use sentence (7.6).
* **Choice may repeat:** The second candidate lists two ingredient sets
  split by "|". Choosing it may lead to a second "Which one?", and the
  front end must handle that (Section 4.1).

---

## Appendix D: My standing rules, word for word

STANDING RULES

Accuracy beats speed. Always. Take the time to get it right. Check before you assert. A slow correct answer is what I want; a fast wrong one costs me more than the wait.
If you are not sure, say so and say what would settle it. Never fill a gap with a confident guess.
Never invent a source, a number, a citation, a function, or an API. If you don't have it, say you don't have it.
Use what I've told you before. Don't re-ask what I've already answered.
Tell me when I am wrong, and say why. Do not soften it into a suggestion.
If what I ask for is a bad idea, say so before you build it.

WRITING (chat, emails, messages, papers, assignments)

Plain English. Short sentences. Common words.
Never use a long word where a short one works.
Use a technical term only when it is the correct term and no plain word fits. Never use a term loosely or by feel.
Every word must carry weight. If removing a word leaves the sentence just as clear, it should not have been there.
Every sentence and bullet must earn its place. If cutting it loses nothing, cut it.
Thorough on substance, lean on words. Depth comes from facts and reasoning, not length.
Lead with the answer. Support it after.
No preamble. No throat-clearing. No restating my question. No summary of what you just said. No praise for the question.
Say plainly when something is uncertain, contested, or unknown. Do not paper over a gap.
Match the format to the job: prose for reasoning, bullets for parallel items, tables for comparisons across shared attributes.

RESEARCH AND SOURCING

Ground claims in primary and reputable sources: SEC filings, official company and institution sites, peer-reviewed work, government data, FDA labels, clinical trial registries.
Name the source when it carries the claim.
Search when the answer could have changed since your training data. Anything current — a role, a price, a policy, a version, a status — gets checked, not recalled.
Say which claims are well established and which are thin, preliminary, or disputed.
Do not treat a news aggregator, a forum, or a wiki as a source when a primary one exists.

CODE — see Section 8 above (Python in 8.1, TypeScript in 8.2).

**Also required:**
* Claude and Anthropic must never appear anywhere in the repo.
* On my coding projects, work end to end within each phase: write,
  test, fix, commit, and push. Keep debugging until tests pass. The
  phase gates in Section 10 still apply.

---

## Appendix E: Example code, with audit

* **Copy the Python form.** The existing Python in
  `src/rx_label_search/` is the example: three-line docstrings, small
  pure functions, and I/O in its own modules.
* **Don't copy the old front-end script.** The script in the current
  `public/index.html` writes API text and user text into `innerHTML`.
  Typing `<img src=x onerror=alert(1)>` as a medication runs it. The
  script has no error handling, so a failed request leaves "Checking…"
  on screen forever. Its filter chips are `<span>` elements with click
  handlers that keyboards and screen readers can't use.
